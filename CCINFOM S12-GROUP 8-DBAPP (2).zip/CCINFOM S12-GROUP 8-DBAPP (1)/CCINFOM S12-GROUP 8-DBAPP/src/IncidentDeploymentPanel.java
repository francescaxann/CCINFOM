import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class IncidentDeploymentPanel extends JPanel {
    private JTable pendingIncidentsTable;
    private DefaultTableModel pendingModel;
    private JTable availableStaffTable;
    private DefaultTableModel staffModel;

    public IncidentDeploymentPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        initializeComponents();
        loadPendingIncidents();
        loadAvailableStaff();
    }

    private void initializeComponents() {
        // Pending incidents table
        pendingModel = new DefaultTableModel(
                new String[]{"Report ID", "Event Type", "Location", "Date", "Status"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        pendingIncidentsTable = new JTable(pendingModel);
        pendingIncidentsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JPanel pendingPanel = new JPanel(new BorderLayout());
        pendingPanel.setBorder(BorderFactory.createTitledBorder("Pending Incidents"));
        pendingPanel.add(new JScrollPane(pendingIncidentsTable), BorderLayout.CENTER);

        // Available staff table
        staffModel = new DefaultTableModel(
                new String[]{"Staff ID", "Name", "Position", "Assigned Area"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        availableStaffTable = new JTable(staffModel);
        availableStaffTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JPanel staffPanel = new JPanel(new BorderLayout());
        staffPanel.setBorder(BorderFactory.createTitledBorder("Available Staff"));
        staffPanel.add(new JScrollPane(availableStaffTable), BorderLayout.CENTER);

        // Split pane for dual tables
        JSplitPane splitPane = new JSplitPane(
                JSplitPane.VERTICAL_SPLIT,
                pendingPanel,
                staffPanel
        );
        splitPane.setResizeWeight(0.5);
        add(splitPane, BorderLayout.CENTER);

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        JButton refreshButton = new JButton("Refresh");
        refreshButton.addActionListener(e -> refreshTables());

        JButton assignButton = new JButton("Assign Selected Staff");
        assignButton.addActionListener(e -> assignStaffToIncident());

        buttonPanel.add(refreshButton);
        buttonPanel.add(assignButton);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void assignStaffToIncident() {
        int incidentRow = pendingIncidentsTable.getSelectedRow();
        int staffRow = availableStaffTable.getSelectedRow();

        if (incidentRow == -1 || staffRow == -1) {
            JOptionPane.showMessageDialog(this,
                    "Please select both an incident and a staff member",
                    "Selection Required",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int reportId = (int) pendingModel.getValueAt(incidentRow, 0);
        int staffId = (int) staffModel.getValueAt(staffRow, 0);

        try (Connection con = DBConnector.getConnection()) {
            // Update incident record
            PreparedStatement ps = con.prepareStatement(
                    "UPDATE Incident SET staffID = ?, status = 'Assigned' WHERE reportID = ?"
            );
            ps.setInt(1, staffId);
            ps.setInt(2, reportId);
            int rowsUpdated = ps.executeUpdate();

            if (rowsUpdated > 0) {
                // Log assignment
                logAssignment(con, reportId, staffId);

                JOptionPane.showMessageDialog(this,
                        "Staff assigned to incident successfully!",
                        "Assignment Complete",
                        JOptionPane.INFORMATION_MESSAGE);
                refreshTables();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Failed to assign staff. Incident may have been reassigned.",
                        "Assignment Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Database Error: " + ex.getMessage(),
                    "Assignment Failed",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void logAssignment(Connection con, int reportId, int staffId) throws SQLException {
        PreparedStatement ps = con.prepareStatement(
                "INSERT INTO AssignmentLog (reportID, staffID, assignmentDate) VALUES (?, ?, CURDATE())"
        );
        ps.setInt(1, reportId);
        ps.setInt(2, staffId);
        ps.executeUpdate();
    }

    private void loadPendingIncidents() {
        pendingModel.setRowCount(0);

        try (Connection con = DBConnector.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(
                    "SELECT reportID, eventType, location, date, status " +
                            "FROM Incident " +
                            "WHERE status IN ('Pending', 'Unassigned') " +
                            "ORDER BY date DESC"
            );

            while (rs.next()) {
                pendingModel.addRow(new Object[]{
                        rs.getInt("reportID"),
                        rs.getString("eventType"),
                        rs.getString("location"),
                        rs.getDate("date").toString(),
                        rs.getString("status")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Error loading incidents: " + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadAvailableStaff() {
        staffModel.setRowCount(0);

        try (Connection con = DBConnector.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(
                    "SELECT s.staffID, r.firstName, r.lastName, s.position, s.assignedArea " +
                            "FROM Staff s " +
                            "JOIN Residents r ON s.residentID = r.residentID " +
                            "WHERE s.officeStatus = 'Active' " +
                            "AND s.staffID NOT IN (" +
                            "   SELECT staffID FROM Incident WHERE status IN ('Assigned', 'Under Investigation')" +
                            ")"
            );

            while (rs.next()) {
                staffModel.addRow(new Object[]{
                        rs.getInt("staffID"),
                        rs.getString("firstName") + " " + rs.getString("lastName"),
                        rs.getString("position"),
                        rs.getString("assignedArea")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Error loading staff: " + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void refreshTables() {
        loadPendingIncidents();
        loadAvailableStaff();
    }
}