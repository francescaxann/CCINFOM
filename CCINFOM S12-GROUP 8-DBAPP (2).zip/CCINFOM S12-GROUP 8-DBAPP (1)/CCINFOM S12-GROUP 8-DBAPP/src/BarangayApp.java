import javax.swing.*;
import java.awt.*;

public class BarangayApp extends JFrame {

    private final JLabel statusLabel;

    public BarangayApp() {
        setTitle("Barangay Records Management System");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Set layout
        setLayout(new BorderLayout());

        // Create tabs
        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Residents", new ResidentsPanel());
        tabs.addTab("Staff", new StaffPanel());
        tabs.addTab("Incidents", new IncidentPanel());
        tabs.addTab("Projects", new ProjectPanel());
        tabs.addTab("Reports", new ReportsPanel());
        tabs.addTab("Incident Deployment", new IncidentDeploymentPanel());
        tabs.addTab("Staff Assignment", new StaffAssignmentPanel());
        tabs.addTab("Certificates", new ClearancePanel());

        // Add a toolbar for quick actions
        JToolBar toolBar = new JToolBar();
        toolBar.setFloatable(false); // Lock position

        JButton reportAccidentBtn = new JButton("Report Accident");
        reportAccidentBtn.addActionListener(e -> {
            new AccidentReportDialog(BarangayApp.this).setVisible(true);
            setStatus("Accident report dialog opened.");
        });

        // Add more action buttons here if needed
        toolBar.add(reportAccidentBtn);

        // Status bar (bottom)
        statusLabel = new JLabel("Ready");
        JPanel statusPanel = new JPanel(new BorderLayout());
        statusPanel.setBorder(BorderFactory.createEtchedBorder());
        statusPanel.add(statusLabel, BorderLayout.WEST);

        // Add components to main layout
        add(toolBar, BorderLayout.NORTH);
        add(tabs, BorderLayout.CENTER);
        add(statusPanel, BorderLayout.SOUTH);
    }

    public void setStatus(String message) {
        statusLabel.setText(message);
    }

    // You can also expose this method statically or pass it to panels if needed
}
