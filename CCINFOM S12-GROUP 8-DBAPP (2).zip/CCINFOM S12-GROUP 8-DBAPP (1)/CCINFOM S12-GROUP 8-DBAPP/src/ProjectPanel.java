// ProjectPanel.java
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;

public class ProjectPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private JComboBox<StaffItem> staffCombo;
    private JTextField startDateField, endDateField, budgetField;
    private JComboBox<String> statusCombo;
    private JButton updateBtn, deleteBtn;
    private int selectedProjectId = -1;

    public ProjectPanel() {
        setLayout(new BorderLayout());
        initializeTable();
        initializeForm();
        initializeButtons();
    }

    private void initializeTable() {
        model = new DefaultTableModel(new String[]{
                "Project ID", "Lead Staff", "Start Date", "End Date", "Budget", "Status"
        }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                int row = table.getSelectedRow();
                selectedProjectId = (int) table.getValueAt(row, 0);
                populateFormWithSelectedRow(row);
            }
        });

        add(new JScrollPane(table), BorderLayout.CENTER);
        loadProjects();
    }

    private void initializeForm() {
        JPanel form = new JPanel(new GridLayout(0, 2, 5, 5));

        // Staff combo
        staffCombo = new JComboBox<>();
        loadStaff();
        form.add(new JLabel("Lead Staff:"));
        form.add(staffCombo);

        // Dates
        startDateField = new JTextField();
        form.add(new JLabel("Start Date (yyyy-mm-dd):"));
        form.add(startDateField);

        endDateField = new JTextField();
        form.add(new JLabel("End Date (yyyy-mm-dd):"));
        form.add(endDateField);

        // Budget
        budgetField = new JTextField();
        form.add(new JLabel("Budget:"));
        form.add(budgetField);

        // Status
        statusCombo = new JComboBox<>(new String[]{"Planning", "Ongoing", "Completed", "Cancelled"});
        form.add(new JLabel("Status:"));
        form.add(statusCombo);

        add(form, BorderLayout.SOUTH);
    }

    private void initializeButtons() {
        JPanel buttonPanel = new JPanel();

        JButton addBtn = new JButton("Add Project");
        addBtn.addActionListener(e -> addProject());

        updateBtn = new JButton("Update Project");
        updateBtn.setEnabled(false);
        updateBtn.addActionListener(e -> updateProject());

        deleteBtn = new JButton("Delete Project");
        deleteBtn.setEnabled(false);
        deleteBtn.addActionListener(e -> deleteProject());

        buttonPanel.add(addBtn);
        buttonPanel.add(updateBtn);
        buttonPanel.add(deleteBtn);

        add(buttonPanel, BorderLayout.NORTH);
    }

    private void loadStaff() {
        staffCombo.removeAllItems();
        try (Connection con = DBConnector.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(
                    "SELECT s.staffID, r.firstName, r.lastName " +
                            "FROM Staff s JOIN Residents r ON s.residentID = r.residentID"
            );
            while (rs.next()) {
                staffCombo.addItem(new StaffItem(
                        rs.getInt("staffID"),
                        rs.getString("firstName") + " " + rs.getString("lastName")
                ));
            }
        } catch (SQLException e) {
            showError("Error loading staff: " + e.getMessage());
        }
    }

    private void populateFormWithSelectedRow(int row) {
        // Find matching staff
        String staffName = table.getValueAt(row, 1).toString();
        for (int i = 0; i < staffCombo.getItemCount(); i++) {
            if (staffCombo.getItemAt(i).toString().equals(staffName)) {
                staffCombo.setSelectedIndex(i);
                break;
            }
        }

        startDateField.setText(table.getValueAt(row, 2).toString());
        endDateField.setText(table.getValueAt(row, 3).toString());
        budgetField.setText(table.getValueAt(row, 4).toString());
        statusCombo.setSelectedItem(table.getValueAt(row, 5).toString());

        updateBtn.setEnabled(true);
        deleteBtn.setEnabled(true);
    }

    private void addProject() {
        try (Connection con = DBConnector.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO Project (staffID, startDate, endDate, budget, status) " +
                            "VALUES (?, ?, ?, ?, ?)"
            );

            setStatementParameters(ps);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Project added successfully!");
            clearForm();
            loadProjects();
        } catch (SQLException | IllegalArgumentException ex) {
            showError("Error: " + ex.getMessage());
        }
    }

    private void updateProject() {
        try (Connection con = DBConnector.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "UPDATE Project SET staffID=?, startDate=?, endDate=?, budget=?, status=? " +
                            "WHERE projectID=?"
            );

            setStatementParameters(ps);
            ps.setInt(6, selectedProjectId);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Project updated successfully!");
            clearForm();
            loadProjects();
        } catch (SQLException | IllegalArgumentException ex) {
            showError("Error: " + ex.getMessage());
        }
    }

    private void deleteProject() {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete this project?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection con = DBConnector.getConnection()) {
                // First delete from ProjectParticipants to maintain referential integrity
                PreparedStatement deleteParticipants = con.prepareStatement(
                        "DELETE FROM ProjectParticipants WHERE projectID=?"
                );
                deleteParticipants.setInt(1, selectedProjectId);
                deleteParticipants.executeUpdate();

                // Then delete the project
                PreparedStatement deleteProject = con.prepareStatement(
                        "DELETE FROM Project WHERE projectID=?"
                );
                deleteProject.setInt(1, selectedProjectId);
                deleteProject.executeUpdate();

                JOptionPane.showMessageDialog(this, "Project deleted successfully!");
                clearForm();
                loadProjects();
            } catch (SQLException ex) {
                showError("Error: " + ex.getMessage());
            }
        }
    }

    private void setStatementParameters(PreparedStatement ps) throws SQLException {
        StaffItem staff = (StaffItem) staffCombo.getSelectedItem();

        if (staff == null) {
            throw new IllegalArgumentException("No staff member selected.");
        }

        ps.setInt(1, staff.id());
        ps.setDate(2, java.sql.Date.valueOf(LocalDate.parse(startDateField.getText())));
        ps.setDate(3, endDateField.getText().isEmpty() ? null :
                java.sql.Date.valueOf(LocalDate.parse(endDateField.getText())));
        ps.setBigDecimal(4, new java.math.BigDecimal(budgetField.getText()));
        ps.setString(5, (String) statusCombo.getSelectedItem());
    }

    private void clearForm() {
        staffCombo.setSelectedIndex(0);
        startDateField.setText("");
        endDateField.setText("");
        budgetField.setText("");
        statusCombo.setSelectedIndex(0);
        selectedProjectId = -1;
        updateBtn.setEnabled(false);
        deleteBtn.setEnabled(false);
    }

    private void loadProjects() {
        model.setRowCount(0);
        try (Connection con = DBConnector.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(
                    "SELECT p.projectID, CONCAT(r.firstName, ' ', r.lastName) AS staffName, " +
                            "p.startDate, p.endDate, p.budget, p.status " +
                            "FROM Project p " +
                            "JOIN Staff s ON p.staffID = s.staffID " +
                            "JOIN Residents r ON s.residentID = r.residentID"
            );

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("projectID"),
                        rs.getString("staffName"),
                        rs.getDate("startDate").toString(),
                        rs.getDate("endDate") != null ? rs.getDate("endDate").toString() : "",
                        rs.getBigDecimal("budget"),
                        rs.getString("status")
                });
            }
        } catch (SQLException e) {
            showError("Error loading projects: " + e.getMessage());
        }
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Database Error", JOptionPane.ERROR_MESSAGE);
    }

    private record StaffItem(int id, String name) {

        @Override
            public String toString() {
                return name;
            }
        }
}