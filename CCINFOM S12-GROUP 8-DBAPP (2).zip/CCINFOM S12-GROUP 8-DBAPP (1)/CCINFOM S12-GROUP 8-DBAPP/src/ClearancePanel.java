import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ClearancePanel extends JPanel {
    private JComboBox<ResidentItem> residentCombo;
    private JTextArea eligibilityArea;
    private JComboBox<String> certificateCombo;
    private JTextArea purposeArea;
    private JButton generateBtn;
    private JTextArea certificateArea;
    private JButton saveBtn;

    public ClearancePanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        initializeComponents();
    }

    private void initializeComponents() {
        // Form panel
        JPanel formPanel = new JPanel(new GridLayout(0, 2, 5, 5));
        formPanel.setBorder(BorderFactory.createTitledBorder("Certificate Information"));

        residentCombo = new JComboBox<>();
        loadResidents();

        eligibilityArea = new JTextArea(3, 20);
        eligibilityArea.setEditable(false);
        eligibilityArea.setLineWrap(true);
        eligibilityArea.setWrapStyleWord(true);

        certificateCombo = new JComboBox<>(new String[]{
                "Barangay Clearance", "Good Moral Certificate", "Residency Certificate"
        });

        purposeArea = new JTextArea(2, 20);
        purposeArea.setLineWrap(true);
        purposeArea.setWrapStyleWord(true);

        formPanel.add(new JLabel("Resident:"));
        formPanel.add(residentCombo);
        formPanel.add(new JLabel("Eligibility Status:"));
        formPanel.add(new JScrollPane(eligibilityArea));
        formPanel.add(new JLabel("Certificate Type:"));
        formPanel.add(certificateCombo);
        formPanel.add(new JLabel("Purpose:"));
        formPanel.add(new JScrollPane(purposeArea));

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        JButton checkEligibilityBtn = new JButton("Check Eligibility");
        checkEligibilityBtn.addActionListener(e -> checkEligibility());

        generateBtn = new JButton("Generate Certificate");
        generateBtn.setEnabled(false);
        generateBtn.addActionListener(e -> generateCertificate());

        buttonPanel.add(checkEligibilityBtn);
        buttonPanel.add(generateBtn);

        JPanel formContainer = new JPanel(new BorderLayout());
        formContainer.add(formPanel, BorderLayout.CENTER);
        formContainer.add(buttonPanel, BorderLayout.SOUTH);

        add(formContainer, BorderLayout.NORTH);

        // Certificate display
        certificateArea = new JTextArea(10, 50);
        certificateArea.setEditable(false);
        certificateArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        certificateArea.setLineWrap(true);
        certificateArea.setWrapStyleWord(true);

        JPanel certPanel = new JPanel(new BorderLayout());
        certPanel.setBorder(BorderFactory.createTitledBorder("Certificate Preview"));
        certPanel.add(new JScrollPane(certificateArea), BorderLayout.CENTER);

        // Save button
        saveBtn = new JButton("Save Certificate");
        saveBtn.setEnabled(false);
        saveBtn.addActionListener(e -> saveCertificate());

        JPanel savePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        savePanel.add(saveBtn);

        certPanel.add(savePanel, BorderLayout.SOUTH);

        add(certPanel, BorderLayout.CENTER);
    }

    private void loadResidents() {
        residentCombo.removeAllItems();
        try (Connection con = DBConnector.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(
                    "SELECT residentID, firstName, lastName FROM Residents"
            );
            while (rs.next()) {
                residentCombo.addItem(new ResidentItem(
                        rs.getInt("residentID"),
                        rs.getString("firstName") + " " + rs.getString("lastName")
                ));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Error loading residents: " + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void checkEligibility() {
        ResidentItem resident = (ResidentItem) residentCombo.getSelectedItem();
        if (resident == null) return;

        try (Connection con = DBConnector.getConnection()) {
            // Check for pending incidents
            PreparedStatement incidentPs = con.prepareStatement(
                    "SELECT COUNT(*) AS pending FROM Incident " +
                            "WHERE residentID = ? AND status IN ('Pending', 'Under Investigation')"
            );
            incidentPs.setInt(1, resident.id());
            ResultSet incidentRs = incidentPs.executeQuery();

            if (incidentRs.next() && incidentRs.getInt("pending") > 0) {
                eligibilityArea.setText("NOT ELIGIBLE: Resident has pending incidents");
                generateBtn.setEnabled(false);
                return;
            }

            // Check for unresolved violations
            PreparedStatement violationPs = con.prepareStatement(
                    "SELECT COUNT(*) AS unresolved FROM Violations " +
                            "WHERE residentID = ? AND status = 'Unresolved'"
            );
            violationPs.setInt(1, resident.id());
            ResultSet violationRs = violationPs.executeQuery();

            if (violationRs.next() && violationRs.getInt("unresolved") > 0) {
                eligibilityArea.setText("NOT ELIGIBLE: Resident has unresolved violations");
                generateBtn.setEnabled(false);
                return;
            }

            // If all checks pass
            eligibilityArea.setText("ELIGIBLE: Resident meets all requirements");
            generateBtn.setEnabled(true);

        } catch (SQLException ex) {
            eligibilityArea.setText("Error checking eligibility: " + ex.getMessage());
            generateBtn.setEnabled(false);
        }
    }

    private void generateCertificate() {
        ResidentItem resident = (ResidentItem) residentCombo.getSelectedItem();
        String certType = (String) certificateCombo.getSelectedItem();
        String purpose = purposeArea.getText().trim();

        if (resident == null || certType == null || purpose.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please select a resident, certificate type, and enter a purpose",
                    "Input Required",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Generate certificate content
        String certificate = generateCertificateContent(resident.toString(), certType, purpose);
        certificateArea.setText(certificate);
        saveBtn.setEnabled(true);
    }

    private String generateCertificateContent(String residentName, String certType, String purpose) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM dd, yyyy");
        String currentDate = dateFormat.format(new Date());

        return String.format(
                """
                        ================================================================
                                                OFFICE OF THE BARANGAY                  \s
                                             BARANGAY RECORDS MANAGEMENT SYSTEM         \s
                        ================================================================
                        
                                                  %s
                        
                        TO WHOM IT MAY CONCERN:
                        
                        This is to certify that %s, of legal age, Filipino, and a resident\s
                        of this barangay, has been found to be of good moral character and has\s
                        no derogatory record on file in this office as of this date.
                        
                        This certification is issued upon the request of the above-named person\s
                        for %s.
                        
                        Issued this %s at Barangay Hall, City of Manila, Philippines.
                        
                        
                        ___________________________
                        HON. BARANGAY CAPTAIN
                        Barangay Official
                        ================================================================
                        """,
                certType.toUpperCase(), residentName, purpose, currentDate
        );
    }

    private void saveCertificate() {
        ResidentItem resident = (ResidentItem) residentCombo.getSelectedItem();
        String certType = (String) certificateCombo.getSelectedItem();
        String purpose = purposeArea.getText().trim();
        String certificateContent = certificateArea.getText();

        if (resident == null || certType == null || purpose.isEmpty()) {
            return;
        }

        try (Connection con = DBConnector.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO Certificates (residentID, certificateType, purpose, " +
                            "issueDate, certificateContent) VALUES (?, ?, ?, CURDATE(), ?)"
            );
            ps.setInt(1, resident.id());
            ps.setString(2, certType);
            ps.setString(3, purpose);
            ps.setString(4, certificateContent);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this,
                    "Certificate saved successfully!",
                    "Save Complete",
                    JOptionPane.INFORMATION_MESSAGE);

            // Reset form
            purposeArea.setText("");
            certificateArea.setText("");
            saveBtn.setEnabled(false);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error saving certificate: " + ex.getMessage(),
                    "Save Failed",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // Helper class
        private record ResidentItem(int id, String name) {

        @Override
            public String toString() {
                return name;
            }
        }
}
