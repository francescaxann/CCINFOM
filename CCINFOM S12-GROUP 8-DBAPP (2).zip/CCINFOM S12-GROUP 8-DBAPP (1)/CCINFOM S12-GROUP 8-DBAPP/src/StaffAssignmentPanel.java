import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class StaffAssignmentPanel extends JPanel {
    private JComboBox<ProjectItem> projectCombo;
    private JComboBox<StaffItem> staffCombo;
    private JTextField roleField;
    private JTable assignmentsTable;
    private DefaultTableModel assignmentsModel;
    private JButton removeButton;

    public StaffAssignmentPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        initializeComponents();
        loadProjects();
        loadStaff();
        loadCurrentAssignments();
    }

    private void initializeComponents() {
        // Form panel
        JPanel formPanel = new JPanel(new GridLayout(0, 2, 5, 5));
        formPanel.setBorder(BorderFactory.createTitledBorder("Assign Staff to Project"));

        projectCombo = new JComboBox<>();
        staffCombo = new JComboBox<>();
        roleField = new JTextField();

        formPanel.add(new JLabel("Project:"));
        formPanel.add(projectCombo);
        formPanel.add(new JLabel("Staff Member:"));
        formPanel.add(staffCombo);
        formPanel.add(new JLabel("Role:"));
        formPanel.add(roleField);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton assignButton = new JButton("Assign to Project");
        assignButton.addActionListener(e -> assignStaffToProject());
        buttonPanel.add(assignButton);

        JPanel formContainer = new JPanel(new BorderLayout());
        formContainer.add(formPanel, BorderLayout.CENTER);
        formContainer.add(buttonPanel, BorderLayout.SOUTH);

        add(formContainer, BorderLayout.NORTH);

        // Current assignments table
        assignmentsModel = new DefaultTableModel(
                new String[]{"Assignment ID", "Project", "Staff", "Role"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        assignmentsTable = new JTable(assignmentsModel);
        assignmentsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createTitledBorder("Current Assignments"));
        tablePanel.add(new JScrollPane(assignmentsTable), BorderLayout.CENTER);

        // Remove button
        removeButton = new JButton("Remove Assignment");
        removeButton.setEnabled(false);
        removeButton.addActionListener(e -> removeAssignment());

        assignmentsTable.getSelectionModel().addListSelectionListener(e -> removeButton.setEnabled(assignmentsTable.getSelectedRow() != -1));

        JPanel removePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        removePanel.add(removeButton);

        tablePanel.add(removePanel, BorderLayout.SOUTH);

        add(tablePanel, BorderLayout.CENTER);
    }

    private void loadProjects() {
        projectCombo.removeAllItems();
        try (Connection con = DBConnector.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(
                    "SELECT projectID, CONCAT('Project ', projectID, ' - ', status) AS projectInfo " +
                            "FROM Project"
            );
            while (rs.next()) {
                projectCombo.addItem(new ProjectItem(
                        rs.getInt("projectID"),
                        rs.getString("projectInfo")
                ));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Error loading projects: " + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadStaff() {
        staffCombo.removeAllItems();
        try (Connection con = DBConnector.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(
                    "SELECT s.staffID, r.firstName, r.lastName " +
                            "FROM Staff s " +
                            "JOIN Residents r ON s.residentID = r.residentID " +
                            "WHERE s.officeStatus = 'Active'"
            );
            while (rs.next()) {
                staffCombo.addItem(new StaffItem(
                        rs.getInt("staffID"),
                        rs.getString("firstName") + " " + rs.getString("lastName")
                ));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Error loading staff: " + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadCurrentAssignments() {
        assignmentsModel.setRowCount(0);
        try (Connection con = DBConnector.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(
                    "SELECT pa.participationID, p.projectID, " +
                            "CONCAT('Project ', p.projectID, ' - ', p.status) AS projectInfo, " +
                            "CONCAT(r.firstName, ' ', r.lastName) AS staffName, " +
                            "r.residentID, pa.role " +
                            "FROM ProjectParticipants pa " +
                            "JOIN Project p ON pa.projectID = p.projectID " +
                            "JOIN Residents r ON pa.residentID = r.residentID"
            );

            while (rs.next()) {
                assignmentsModel.addRow(new Object[]{
                        rs.getInt("participationID"),
                        rs.getString("projectInfo"),
                        rs.getString("staffName"),
                        rs.getString("role")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Error loading assignments: " + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void assignStaffToProject() {
        ProjectItem project = (ProjectItem) projectCombo.getSelectedItem();
        StaffItem staff = (StaffItem) staffCombo.getSelectedItem();
        String role = roleField.getText().trim();

        if (project == null || staff == null || role.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please select both a project and staff member, and enter a role",
                    "Input Required",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection con = DBConnector.getConnection()) {
            // First get resident ID from staff ID
            int residentId = getResidentIdFromStaff(con, staff.id());

            if (residentId == -1) {
                throw new SQLException("Resident not found for staff member");
            }

            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO ProjectParticipants (projectID, residentID, role) VALUES (?, ?, ?)"
            );
            ps.setInt(1, project.id());
            ps.setInt(2, residentId);
            ps.setString(3, role);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this,
                    "Staff assigned to project successfully!",
                    "Assignment Complete",
                    JOptionPane.INFORMATION_MESSAGE);

            // Clear form and refresh
            roleField.setText("");
            loadCurrentAssignments();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error assigning staff: " + ex.getMessage(),
                    "Assignment Failed",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private int getResidentIdFromStaff(Connection con, int staffId) throws SQLException {
        PreparedStatement ps = con.prepareStatement(
                "SELECT residentID FROM Staff WHERE staffID = ?"
        );
        ps.setInt(1, staffId);
        ResultSet rs = ps.executeQuery();
        return rs.next() ? rs.getInt("residentID") : -1;
    }

    private void removeAssignment() {
        int row = assignmentsTable.getSelectedRow();
        if (row == -1) return;

        int assignmentId = (int) assignmentsModel.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Remove this assignment?",
                "Confirm Removal",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection con = DBConnector.getConnection()) {
                PreparedStatement ps = con.prepareStatement(
                        "DELETE FROM ProjectParticipants WHERE participationID = ?"
                );
                ps.setInt(1, assignmentId);
                int rowsDeleted = ps.executeUpdate();

                if (rowsDeleted > 0) {
                    JOptionPane.showMessageDialog(this,
                            "Assignment removed successfully!",
                            "Removal Complete",
                            JOptionPane.INFORMATION_MESSAGE);
                    loadCurrentAssignments();
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this,
                        "Error removing assignment: " + ex.getMessage(),
                        "Removal Failed",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Helper classes
        private record ProjectItem(int id, String name) {

        @Override
            public String toString() {
                return name;
            }
        }

    private record StaffItem(int id, String name) {

        @Override
            public String toString() {
                return name;
            }
        }
}
