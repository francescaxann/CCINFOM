import javax.swing.*;
import java.awt.*;

public class SplashScreen extends JWindow {
    public SplashScreen() {
        JPanel content = new JPanel(new BorderLayout());
        JLabel label = new JLabel("Loading Barangay System...", JLabel.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 20));
        content.add(label, BorderLayout.CENTER);

        // Optional: add an image
        // content.add(new JLabel(new ImageIcon("resources/logo.png")), BorderLayout.NORTH);

        setContentPane(content);
        setSize(400, 200);
        setLocationRelativeTo(null);
    }

    public void showSplash() {
        setVisible(true);
        try {
            Thread.sleep(2000); // Simulate loading
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        setVisible(false);
        dispose();
    }
}
