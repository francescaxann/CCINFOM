import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.Statement;

public class AccidentReportDialog extends JDialog {
    private JComboBox<ResidentItem> reporterCombo;
    private JTextField locationField;
    private JTextArea descriptionArea;
    private DefaultTableModel involvedModel;
    private JComboBox<StaffItem> responderCombo;
    private final List<ResidentRolePair> involvedResidents = new ArrayList<>();

    public AccidentReportDialog(JFrame parent) {
        super(parent, "Report Accident", true);
        setSize(600, 500);
        setLocationRelativeTo(parent);
        initializeComponents();
        loadResidents();
        loadStaff();
    }

    private void initializeComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Incident details panel
        JPanel detailsPanel = new JPanel(new GridLayout(0, 2, 5, 5));

        reporterCombo = new JComboBox<>();
        locationField = new JTextField();
        descriptionArea = new JTextArea(4, 20);
        descriptionArea.setLineWrap(true);

        detailsPanel.add(new JLabel("Reporter:"));
        detailsPanel.add(reporterCombo);
        detailsPanel.add(new JLabel("Location:"));
        detailsPanel.add(locationField);
        detailsPanel.add(new JLabel("Description:"));
        detailsPanel.add(new JScrollPane(descriptionArea));

        mainPanel.add(detailsPanel, BorderLayout.NORTH);

        // Involved residents panel
        JPanel involvedPanel = new JPanel(new BorderLayout(5, 5));
        involvedModel = new DefaultTableModel(new String[]{"Resident ID", "Name", "Role"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable involvedResidentsTable = new JTable(involvedModel);

        JButton addInvolvedBtn = new JButton("Add Involved Resident");
        addInvolvedBtn.addActionListener(e -> addInvolvedResident());

        involvedPanel.add(new JLabel("Involved Residents:"), BorderLayout.NORTH);
        involvedPanel.add(new JScrollPane(involvedResidentsTable), BorderLayout.CENTER);
        involvedPanel.add(addInvolvedBtn, BorderLayout.SOUTH);

        mainPanel.add(involvedPanel, BorderLayout.CENTER);

        // Responding staff panel
        JPanel responderPanel = new JPanel(new BorderLayout(5, 5));
        responderCombo = new JComboBox<>();

        responderPanel.add(new JLabel("Responding Staff:"), BorderLayout.NORTH);
        responderPanel.add(responderCombo, BorderLayout.CENTER);

        mainPanel.add(responderPanel, BorderLayout.SOUTH);

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton submitBtn = new JButton("Submit Accident Report");
        submitBtn.addActionListener(e -> submitAccidentReport());

        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.addActionListener(e -> dispose());

        buttonPanel.add(cancelBtn);
        buttonPanel.add(submitBtn);

        add(mainPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void loadResidents() {
        reporterCombo.removeAllItems();
        try (Connection con = DBConnector.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT residentID, firstName, lastName FROM Residents");
            while (rs.next()) {
                reporterCombo.addItem(new ResidentItem(
                        rs.getInt("residentID"),
                        rs.getString("firstName") + " " + rs.getString("lastName")
                ));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading residents: " + e.getMessage());
        }
    }

    private void loadStaff() {
        responderCombo.removeAllItems();
        try (Connection con = DBConnector.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(
                    "SELECT s.staffID, r.firstName, r.lastName " +
                            "FROM Staff s JOIN Residents r ON s.residentID = r.residentID " +
                            "WHERE s.officeStatus = 'Active'"
            );
            while (rs.next()) {
                responderCombo.addItem(new StaffItem(
                        rs.getInt("staffID"),
                        rs.getString("firstName") + " " + rs.getString("lastName")
                ));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading staff: " + e.getMessage());
        }
    }

    private void addInvolvedResident() {
        JDialog involvedDialog = new JDialog(this, "Add Involved Resident", true);
        involvedDialog.setSize(400, 200);
        involvedDialog.setLayout(new GridLayout(0, 2, 5, 5));

        JComboBox<ResidentItem> residentCombo = new JComboBox<>();
        JTextField roleField = new JTextField();

        // Load residents into combo
        try (Connection con = DBConnector.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT residentID, firstName, lastName FROM Residents");
            while (rs.next()) {
                residentCombo.addItem(new ResidentItem(
                        rs.getInt("residentID"),
                        rs.getString("firstName") + " " + rs.getString("lastName")
                ));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(involvedDialog, "Error loading residents: " + e.getMessage());
        }

        involvedDialog.add(new JLabel("Resident:"));
        involvedDialog.add(residentCombo);
        involvedDialog.add(new JLabel("Role (e.g., Victim, Witness):"));
        involvedDialog.add(roleField);

        JPanel buttonPanel = createDialogButtons(involvedDialog, residentCombo, roleField);

        involvedDialog.add(new JLabel());
        involvedDialog.add(buttonPanel);
        involvedDialog.setLocationRelativeTo(this);
        involvedDialog.setVisible(true);
    }

    private JPanel createDialogButtons(JDialog dialog, JComboBox<ResidentItem> residentCombo, JTextField roleField) {
        JButton addBtn = new JButton("Add");
        addBtn.addActionListener(e -> {
            ResidentItem resident = (ResidentItem) residentCombo.getSelectedItem();
            if (resident != null && !roleField.getText().isEmpty()) {
                involvedResidents.add(new ResidentRolePair(resident.id(), roleField.getText()));
                updateInvolvedTable();
                dialog.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog, "Please select a resident and enter a role");
            }
        });

        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.addActionListener(e -> dialog.dispose());

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(cancelBtn);
        buttonPanel.add(addBtn);
        return buttonPanel;
    }

    private void updateInvolvedTable() {
        involvedModel.setRowCount(0);
        for (ResidentRolePair pair : involvedResidents) {
            try (Connection con = DBConnector.getConnection()) {
                PreparedStatement ps = con.prepareStatement(
                        "SELECT firstName, lastName FROM Residents WHERE residentID = ?"
                );
                ps.setInt(1, pair.residentId);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    involvedModel.addRow(new Object[]{
                            pair.residentId,
                            rs.getString("firstName") + " " + rs.getString("lastName"),
                            pair.role
                    });
                }
            } catch (SQLException e) {
                // Handle error
            }
        }
    }

    private void submitAccidentReport() {
        if (reporterCombo.getSelectedItem() == null ||
                responderCombo.getSelectedItem() == null ||
                locationField.getText().isEmpty() ||
                descriptionArea.getText().isEmpty()) {

            JOptionPane.showMessageDialog(this, "Please fill all required fields");
            return;
        }

        try (Connection con = DBConnector.getConnection()) {
            con.setAutoCommit(false);  // Start transaction

            try {
                // Step 1: Create incident record
                PreparedStatement incidentPs = con.prepareStatement(
                        "INSERT INTO Incident (residentID, staffID, eventType, date, time, " +
                                "location, personInvolved, status) VALUES (?, ?, ?, CURDATE(), CURTIME(), ?, ?, ?)",
                        PreparedStatement.RETURN_GENERATED_KEYS
                );

                ResidentItem reporter = (ResidentItem) reporterCombo.getSelectedItem();
                StaffItem responder = (StaffItem) responderCombo.getSelectedItem();

                incidentPs.setInt(1, reporter.id());
                incidentPs.setInt(2, responder.id());
                incidentPs.setString(3, "Accident");
                incidentPs.setString(4, locationField.getText());
                incidentPs.setString(5, descriptionArea.getText());
                incidentPs.setString(6, "Under Investigation");

                int affectedRows = incidentPs.executeUpdate();
                if (affectedRows == 0) {
                    throw new SQLException("Creating incident failed, no rows affected.");
                }

                // Get generated report ID
                int reportId;
                try (ResultSet generatedKeys = incidentPs.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        reportId = generatedKeys.getInt(1);
                    } else {
                        throw new SQLException("Creating incident failed, no ID obtained.");
                    }
                }

                // Step 2: Create involved resident records
                for (ResidentRolePair pair : involvedResidents) {
                    PreparedStatement involvedPs = con.prepareStatement(
                            "INSERT INTO IncidentParticipants (reportID, residentID, role) " +
                                    "VALUES (?, ?, ?)"
                    );
                    involvedPs.setInt(1, reportId);
                    involvedPs.setInt(2, pair.residentId);
                    involvedPs.setString(3, pair.role);
                    involvedPs.executeUpdate();
                }

                con.commit();  // Commit transaction
                JOptionPane.showMessageDialog(this, "Accident report submitted successfully!");
                dispose();

            } catch (SQLException ex) {
                con.rollback();  // Rollback on error
                throw ex;
            } finally {
                con.setAutoCommit(true);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error submitting report: " + ex.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // Helper classes
        private record ResidentItem(int id, String name) {

        @Override
            public String toString() {
                return name;
            }
        }

    private record StaffItem(int id, String name) {

        @Override
            public String toString() {
                return name;
            }
        }

    private static class ResidentRolePair {
        int residentId;
        String role;

        public ResidentRolePair(int residentId, String role) {
            this.residentId = residentId;
            this.role = role;
        }
    }
}
