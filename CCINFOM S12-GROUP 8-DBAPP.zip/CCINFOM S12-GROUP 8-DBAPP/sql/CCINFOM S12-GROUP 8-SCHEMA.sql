CREATE DATABASE IF NOT EXISTS barangay_db;
USE barangay_db;

CREATE TABLE IF NOT EXISTS Residents (
    residentID INT AUTO_INCREMENT PRIMARY KEY,
    firstName VARCHAR(50),
    lastName VARCHAR(50),
    birthDate DATE,
    gender ENUM('Male', 'Female'),
    civilStatus ENUM('Single', 'Married', 'Divorced', 'Widowed'),
    occupation VARCHAR(100),
    contactNo VARCHAR(20),
    streetName VARCHAR(100),
    residencyStart DATE,
    satisfactionRating DECIMAL(3,2)
);

CREATE TABLE IF NOT EXISTS Staff (
    staffID INT AUTO_INCREMENT PRIMARY KEY,
    residentID INT,
    position VARCHAR(50),
    startTerm DATE,
    endTerm DATE,
    officeStatus ENUM('Active', 'Inactive'),
    assignedArea VARCHAR(100),
    FOREIGN KEY (residentID) REFERENCES Residents(residentID)
);

CREATE TABLE IF NOT EXISTS Incident (
    reportID INT AUTO_INCREMENT PRIMARY KEY,
    residentID INT,
    staffID INT,
    eventType VARCHAR(100),
    date DATE,
    time TIME,
    location VARCHAR(100),
    personInvolved VARCHAR(100),
    status VARCHAR(50),
    FOREIGN KEY (residentID) REFERENCES Residents(residentID),
    FOREIGN KEY (staffID) REFERENCES Staff(staffID)
);

CREATE TABLE IF NOT EXISTS Project (
    projectID INT AUTO_INCREMENT PRIMARY KEY,
    staffID INT,
    startDate DATE,
    endDate DATE,
    budget DECIMAL(10,2),
    status VARCHAR(50),
    FOREIGN KEY (staffID) REFERENCES Staff(staffID)
);

CREATE TABLE IF NOT EXISTS ProjectParticipants (
    participationID INT AUTO_INCREMENT PRIMARY KEY,
    projectID INT NOT NULL,
    residentID INT NOT NULL,
    role VARCHAR(50) NOT NULL,
    UNIQUE (projectID, residentID),
    FOREIGN KEY (projectID) REFERENCES Project(projectID),
    FOREIGN KEY (residentID) REFERENCES Residents(residentID)
);

CREATE TABLE IF NOT EXISTS IncidentParticipants (
    participationID INT AUTO_INCREMENT PRIMARY KEY,
    reportID INT,
    residentID INT,
    role VARCHAR(50),
    FOREIGN KEY (reportID) REFERENCES Incident(reportID),
    FOREIGN KEY (residentID) REFERENCES Residents(residentID)
);

-- For incident deployment tracking
CREATE TABLE IF NOT EXISTS AssignmentLog (
    logID INT AUTO_INCREMENT PRIMARY KEY,
    reportID INT,
    staffID INT,
    assignmentDate DATE,
    FOREIGN KEY (reportID) REFERENCES Incident(reportID),
    FOREIGN KEY (staffID) REFERENCES Staff(staffID)
);

-- For certificate management
CREATE TABLE IF NOT EXISTS Certificates (
    certificateID INT AUTO_INCREMENT PRIMARY KEY,
    residentID INT,
    certificateType VARCHAR(100),
    purpose TEXT,
    issueDate DATE,
    certificateContent TEXT,
    FOREIGN KEY (residentID) REFERENCES Residents(residentID)
);

-- For violation tracking (used in eligibility check)
CREATE TABLE IF NOT EXISTS Violations (
    violationID INT AUTO_INCREMENT PRIMARY KEY,
    residentID INT,
    violationType VARCHAR(100),
    date DATE,
    description TEXT,
    status ENUM('Resolved', 'Unresolved'),
    FOREIGN KEY (residentID) REFERENCES Residents(residentID)
);
