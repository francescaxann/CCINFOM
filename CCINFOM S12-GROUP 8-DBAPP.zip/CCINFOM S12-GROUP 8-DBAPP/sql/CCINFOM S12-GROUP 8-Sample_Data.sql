SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE IncidentParticipants;
TRUNCATE TABLE ProjectParticipants;
TRUNCATE TABLE AssignmentLog;
TRUNCATE TABLE Certificates;
TRUNCATE TABLE Incident;
TRUNCATE TABLE Project;
TRUNCATE TABLE Staff;
TRUNCATE TABLE Residents;
SET FOREIGN_KEY_CHECKS = 1;

-- Insert sample residents (15 records)
INSERT INTO Residents (firstName, lastName, birthDate, gender, civilStatus, occupation, contactNo, streetName, residencyStart, satisfactionRating) VALUES
('Juan', 'Dela Cruz', '1980-05-15', 'Male', 'Married', 'Teacher', '09123456789', 'Mabini Street', '2010-01-15', 4.5),
('Maria', 'Santos', '1985-08-20', 'Female', 'Married', 'Nurse', '09123456788', 'Rizal Avenue', '2012-05-10', 4.2),
('Pedro', 'Gonzales', '1975-03-10', 'Male', 'Single', 'Driver', '09123456787', 'Bonifacio Street', '2008-11-22', 3.8),
('Ana', 'Reyes', '1990-11-25', 'Female', 'Single', 'Accountant', '09123456786', 'Aguinaldo Road', '2015-07-18', 4.7),
('Luis', 'Torres', '1982-07-30', 'Male', 'Married', 'Engineer', '09123456785', 'Quezon Boulevard', '2011-09-05', 4.0),
('Carmen', 'Lim', '1978-12-05', 'Female', 'Widowed', 'Business Owner', '09123456784', 'Marcos Highway', '2009-04-12', 4.3),
('Eduardo', 'Garcia', '1995-04-18', 'Male', 'Single', 'Student', '09123456783', 'Roxas Street', '2018-02-28', 4.1),
('Sofia', 'Aquino', '1987-09-12', 'Female', 'Married', 'Doctor', '09123456782', 'Osmeña Avenue', '2013-08-15', 4.8),
('Roberto', 'Chua', '1970-06-22', 'Male', 'Divorced', 'Retired', '09123456781', 'MacArthur Highway', '2005-10-20', 3.9),
('Lourdes', 'Tan', '1983-01-30', 'Female', 'Married', 'Teacher', '09123456780', 'Legarda Street', '2010-12-10', 4.4),
('Antonio', 'Ong', '1992-07-08', 'Male', 'Single', 'Software Developer', '09123456779', 'Recto Avenue', '2016-03-25', 4.6),
('Teresa', 'Sy', '1972-11-15', 'Female', 'Widowed', 'Store Owner', '09123456778', 'Taft Avenue', '2007-06-18', 4.0),
('Fernando', 'Lopez', '1988-02-28', 'Male', 'Single', 'Architect', '09123456777', 'Ayala Avenue', '2014-09-30', 4.5),
('Isabel', 'Romero', '1984-10-10', 'Female', 'Married', 'Lawyer', '09123456776', 'Buendia Street', '2012-11-05', 4.7),
('Ricardo', 'Navarro', '1977-04-05', 'Male', 'Divorced', 'Police Officer', '09123456775', 'Edsa', '2009-08-22', 4.2);

-- Insert staff members (8 records)
INSERT INTO Staff (residentID, position, startTerm, endTerm, officeStatus, assignedArea) VALUES
(2, 'Barangay Captain', '2020-06-30', '2023-06-30', 'Active', 'Entire Barangay'),
(4, 'Barangay Secretary', '2020-06-30', '2023-06-30', 'Active', 'Office'),
(6, 'Barangay Treasurer', '2020-06-30', '2023-06-30', 'Active', 'Office'),
(8, 'Barangay Health Worker', '2021-01-15', '2023-01-15', 'Active', 'Health Center'),
(10, 'Barangay Tanod', '2021-01-15', '2023-01-15', 'Active', 'Zone 1'),
(12, 'Barangay Tanod', '2021-01-15', '2023-01-15', 'Active', 'Zone 2'),
(14, 'Barangay Kagawad', '2020-06-30', '2023-06-30', 'Active', 'Committee on Peace and Order'),
(1, 'Barangay Kagawad', '2020-06-30', '2023-06-30', 'Inactive', 'Committee on Education');

-- Insert sample incidents (10 records)
INSERT INTO Incident (residentID, staffID, eventType, date, time, location, personInvolved, status) VALUES
(3, 2, 'Noise Complaint', '2023-01-05', '22:30:00', 'Mabini Street', 'Neighbor', 'Resolved'),
(5, 4, 'Property Dispute', '2023-01-10', '14:15:00', 'Quezon Boulevard', 'Family members', 'Under Investigation'),
(7, 6, 'Street Fight', '2023-01-15', '19:45:00', 'Roxas Street', 'Two residents', 'Resolved'),
(9, 8, 'Illegal Parking', '2023-01-20', '08:30:00', 'MacArthur Highway', 'Vehicle owner', 'Pending'),
(11, 5, 'Stray Animals', '2023-01-25', '10:00:00', 'Recto Avenue', 'Dogs', 'Assigned'),  -- StaffID 5 (valid)
(13, 6, 'Littering', '2023-02-01', '16:20:00', 'Ayala Avenue', 'Unknown', 'Resolved'),    -- StaffID 6 (valid)
(15, 7, 'Water Leak', '2023-02-05', '07:45:00', 'Edsa', 'Water utility', 'Under Investigation'),  -- StaffID 7 (valid)
(2, 1, 'Power Outage', '2023-02-10', '20:15:00', 'Rizal Avenue', 'Electric company', 'Pending'),
(4, 2, 'Suspicious Person', '2023-02-15', '23:30:00', 'Aguinaldo Road', 'Unknown male', 'Assigned'),
(6, 5, 'Road Accident', '2023-02-20', '12:45:00', 'Marcos Highway', 'Two vehicles', 'Under Investigation');  -- StaffID 5 (valid)

-- Insert incident participants (for the accidents and fights)
INSERT INTO IncidentParticipants (reportID, residentID, role) VALUES
(3, 7, 'Aggressor'),
(3, 15, 'Victim'),
(10, 5, 'Driver 1'),
(10, 11, 'Driver 2'),
(10, 3, 'Witness');

-- Insert sample projects (5 records)
INSERT INTO Project (staffID, startDate, endDate, budget, status) VALUES
(2, '2023-01-01', '2023-03-31', 50000.00, 'Ongoing'),
(4, '2023-01-15', '2023-02-28', 25000.00, 'Completed'),
(6, '2023-02-01', '2023-06-30', 75000.00, 'Ongoing'),
(8, '2023-03-01', NULL, 100000.00, 'Planning'),
(10, '2023-01-20', '2023-01-31', 15000.00, 'Completed');

-- Insert project participants
INSERT INTO ProjectParticipants (projectID, residentID, role) VALUES
(1, 3, 'Volunteer'),
(1, 5, 'Coordinator'),
(1, 7, 'Worker'),
(2, 9, 'Supervisor'),
(2, 11, 'Worker'),
(3, 13, 'Team Leader'),
(3, 15, 'Volunteer'),
(4, 1, 'Advisor'),
(4, 2, 'Planner'),
(5, 4, 'Organizer'),
(5, 6, 'Worker');

-- Insert assignment logs
INSERT INTO AssignmentLog (reportID, staffID, assignmentDate) VALUES
(1, 2, '2023-01-05'),
(3, 6, '2023-01-15'),
(5, 5, '2023-01-25'),  -- StaffID 5 (valid)
(7, 7, '2023-02-05'),  -- StaffID 7 (valid)
(9, 2, '2023-02-15');

-- Insert sample certificates (8 records)
INSERT INTO Certificates (residentID, certificateType, purpose, issueDate, certificateContent) VALUES
(1, 'Barangay Clearance', 'Business Permit Application', '2023-01-05', 'Certificate content for Juan Dela Cruz'),
(3, 'Good Moral Certificate', 'College Application', '2023-01-10', 'Certificate content for Pedro Gonzales'),
(5, 'Residency Certificate', 'Passport Application', '2023-01-15', 'Certificate content for Luis Torres'),
(7, 'Barangay Clearance', 'Employment Requirement', '2023-01-20', 'Certificate content for Eduardo Garcia'),
(9, 'Good Moral Certificate', 'Scholarship Application', '2023-01-25', 'Certificate content for Roberto Chua'),
(11, 'Residency Certificate', 'Voter Registration', '2023-02-01', 'Certificate content for Antonio Ong'),
(13, 'Barangay Clearance', 'Bank Loan', '2023-02-05', 'Certificate content for Fernando Lopez'),
(15, 'Good Moral Certificate', 'Job Application', '2023-02-10', 'Certificate content for Ricardo Navarro');