import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class StaffPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private JTextField[] fields;
    private JComboBox<String> statusCombo;
    private static final Color ERROR_COLOR = new Color(255, 200, 200);
    private static final Color HIGHLIGHT_COLOR = new Color(220, 255, 220);

    public StaffPanel() {
        setLayout(new BorderLayout());
        initializeUI();
        loadStaff();
    }

    private void initializeUI() {

        // Table setup
        model = new DefaultTableModel(new String[] {
                "ID", "Resident ID", "Position", "Start Term", "End Term", "Status", "Assigned Area"
        }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(model);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setRowSelectionAllowed(true);
        table.setFocusable(true);
        table.setRowHeight(24);
        table.setSelectionBackground(new Color(220, 220, 255));
        table.setSelectionForeground(Color.BLACK);

        // Container panel with padding
        JPanel containerPanel = new JPanel(new BorderLayout());
        containerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        containerPanel.add(new JScrollPane(table), BorderLayout.CENTER);

        // Form setup with improved spacing
        JPanel form = new JPanel(new GridLayout(0, 2, 10, 10));
        form.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Form setup
        String[] labels = {"Resident ID", "Position", "Start Term (yyyy-mm-dd)",
                "End Term (yyyy-mm-dd)", "Status", "Assigned Area"};

        fields = new JTextField[labels.length];
        for (int i = 0; i < fields.length; i++) {
            if (i == 4) { // Status
                statusCombo = new JComboBox<>(new String[]{"Active", "Inactive"});
                form.add(new JLabel(labels[i]));
                form.add(statusCombo);
            } else {
                form.add(new JLabel(labels[i]));
                fields[i] = new JTextField();

                addFocusHighlighter(fields[i]);

                if (i == 2 || i == 3) {
                    fields[i].setToolTipText("Format: yyyy-mm-dd (e.g., 2023-12-31)");
                }

                form.add(fields[i]);
            }
        }

        // Button panel
        JPanel buttonPanel = createButtonPanel();

        // Selection listener
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                populateFormFromSelectedRow();
            }
        });

        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel southPanel = new JPanel(new BorderLayout());
        southPanel.add(form, BorderLayout.NORTH);
        southPanel.add(buttonPanel, BorderLayout.SOUTH);
        add(southPanel, BorderLayout.SOUTH);

        addFieldFocusListeners();
    }

    private JPanel createButtonPanel() {

        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton clearBtn = new JButton("Clear");

        addBtn.addActionListener(e -> addStaff());
        updateBtn.addActionListener(e -> updateStaff());
        deleteBtn.addActionListener(e -> deleteStaff());
        clearBtn.addActionListener(e -> clearForm());

        panel.add(addBtn);
        panel.add(updateBtn);
        panel.add(deleteBtn);
        panel.add(clearBtn);

        return panel;
    }

    private boolean validateInputs() {
        StringBuilder errors = new StringBuilder();
        boolean isValid = true;

        // Reset all field backgrounds
        for (JTextField field : fields) {
            if (field != null) field.setBackground(Color.WHITE);
        }

        // Field 0: Resident ID
        if (fields[0].getText().trim().isEmpty() || !fields[0].getText().trim().matches("\\d+")) {
            errors.append("- Resident ID must be numeric\n");
            fields[0].setBackground(ERROR_COLOR);
            isValid = false;
        }

        // Field 1: Position
        if (fields[1].getText().trim().isEmpty()) {
            errors.append("- Position is required\n");
            fields[1].setBackground(ERROR_COLOR);
            isValid = false;
        }

        // Field 2: Start Term
        try {
            LocalDate.parse(fields[2].getText().trim());
        } catch (DateTimeParseException | NullPointerException e) {
            errors.append("- Start Term must be in yyyy-mm-dd format\n");
            fields[2].setBackground(ERROR_COLOR);
            isValid = false;
        }

        // Field 3: End Term
        try {
            LocalDate.parse(fields[3].getText().trim());
        } catch (DateTimeParseException | NullPointerException e) {
            errors.append("- End Term must be in yyyy-mm-dd format\n");
            fields[3].setBackground(ERROR_COLOR);
            isValid = false;
        }

        // Field 5: Assigned Area
        if (fields[5].getText().trim().isEmpty()) {
            errors.append("- Assigned Area is required\n");
            fields[5].setBackground(ERROR_COLOR);
            isValid = false;
        }

        if (!isValid) {
            JOptionPane.showMessageDialog(this,
                    "Please fix the following errors:\n\n" + errors,
                    "Input Validation Error",
                    JOptionPane.WARNING_MESSAGE);
        }

        return !isValid;
    }


    private void loadStaff() {
        model.setRowCount(0);
        try (Connection con = DBConnector.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Staff");
            while (rs.next()) {
                model.addRow(new Object[] {
                        rs.getInt("staffID"),
                        rs.getInt("residentID"),
                        rs.getString("position"),
                        rs.getDate("startTerm").toString(),
                        rs.getDate("endTerm").toString(),
                        rs.getString("officeStatus"),
                        rs.getString("assignedArea")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading staff: " + e.getMessage());
        }
    }

    private void addFieldFocusListeners() {
        for (JTextField field : fields) {
            if (field != null) {
                addFocusHighlighter(field);
            }
        }
    }

    private void addFocusHighlighter(JTextField field) {
        field.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                field.setBackground(HIGHLIGHT_COLOR);
            }

            public void focusLost(java.awt.event.FocusEvent evt) {
                field.setBackground(Color.WHITE);
            }
        });
    }

    private void addStaff() {

        if (validateInputs()) return;

        try {
            String sql = "INSERT INTO Staff (residentID, position, startTerm, endTerm, officeStatus, assignedArea) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";

            try (Connection con = DBConnector.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, Integer.parseInt(fields[0].getText()));
                ps.setString(2, fields[1].getText());
                ps.setString(3, fields[2].getText());
                ps.setString(4, fields[3].getText());
                ps.setString(5, (String) statusCombo.getSelectedItem());
                ps.setString(6, fields[5].getText());

                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Staff member added successfully!");
                loadStaff();
                clearForm();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error adding staff: " + e.getMessage());
        }
    }

    private void updateStaff() {

        if (validateInputs()) return;

        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a staff member to update");
            return;
        }

        int staffId = (int) model.getValueAt(selectedRow, 0);

        try {
            String sql = "UPDATE Staff SET residentID=?, position=?, startTerm=?, " +
                    "endTerm=?, officeStatus=?, assignedArea=? WHERE staffID=?";

            try (Connection con = DBConnector.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, Integer.parseInt(fields[0].getText()));
                ps.setString(2, fields[1].getText());
                ps.setString(3, fields[2].getText());
                ps.setString(4, fields[3].getText());
                ps.setString(5, (String) statusCombo.getSelectedItem());
                ps.setString(6, fields[5].getText());
                ps.setInt(7, staffId);

                int updated = ps.executeUpdate();
                if (updated > 0) {
                    JOptionPane.showMessageDialog(this, "Staff member updated successfully!");
                    loadStaff();
                    clearForm();
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error updating staff: " + e.getMessage());
        }
    }

    private void deleteStaff() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a staff member to delete");
            return;
        }

        int staffId = (int) model.getValueAt(selectedRow, 0);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete staff member ID " + staffId + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection con = DBConnector.getConnection();
                 PreparedStatement ps = con.prepareStatement("DELETE FROM Staff WHERE staffID=?")) {

                ps.setInt(1, staffId);
                int deleted = ps.executeUpdate();
                if (deleted > 0) {
                    JOptionPane.showMessageDialog(this, "Staff member deleted successfully!");
                    loadStaff();
                    clearForm();
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error deleting staff: " + e.getMessage());
            }
        }
    }

    private void populateFormFromSelectedRow() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {

            fields[0].setText(model.getValueAt(selectedRow, 1).toString());
            fields[1].setText(model.getValueAt(selectedRow, 2).toString());
            fields[2].setText(model.getValueAt(selectedRow, 3).toString());
            fields[3].setText(model.getValueAt(selectedRow, 4).toString());
            statusCombo.setSelectedItem(model.getValueAt(selectedRow, 5).toString());
            fields[5].setText(model.getValueAt(selectedRow, 6).toString());
        }
    }

    private void clearForm() {
        for (JTextField field : fields) {
            if (field != null) field.setText("");
        }
        if (statusCombo != null) statusCombo.setSelectedIndex(0);
        table.clearSelection();
    }
}
