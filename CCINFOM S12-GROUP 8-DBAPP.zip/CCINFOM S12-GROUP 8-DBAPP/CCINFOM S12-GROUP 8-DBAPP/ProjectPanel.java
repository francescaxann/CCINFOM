import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class ProjectPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private JComboBox<StaffItem> staffCombo;
    private JTextField startDateField, endDateField, budgetField;
    private JComboBox<String> statusCombo;
    private JButton updateBtn, deleteBtn;
    private int selectedProjectId = -1;
    private static final Color ERROR_COLOR = new Color(255, 200, 200);
    private static final Color HIGHLIGHT_COLOR = new Color(220, 255, 220);

    public ProjectPanel() {
        setLayout(new BorderLayout());
        initializeTable();
        initializeForm();
        initializeButtons();
    }

    private void initializeTable() {
        model = new DefaultTableModel(new String[]{
                "Project ID", "Lead Staff", "Start Date", "End Date", "Budget", "Status"
        }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                int row = table.getSelectedRow();
                selectedProjectId = (int) table.getValueAt(row, 0);
                populateFormWithSelectedRow(row);
            }
        });

        add(new JScrollPane(table), BorderLayout.CENTER);
        loadProjects();
    }

    private void initializeForm() {
        JPanel form = new JPanel(new GridLayout(0, 2, 5, 5));

        // Staff combo
        staffCombo = new JComboBox<>();
        loadStaff();
        form.add(new JLabel("Lead Staff:"));
        form.add(staffCombo);

        // Dates with green highlighting
        startDateField = new JTextField();
        addFocusHighlighter(startDateField);
        startDateField.setToolTipText("Format: yyyy-mm-dd (e.g., 2023-12-31)");
        form.add(new JLabel("Start Date (yyyy-mm-dd):"));
        form.add(startDateField);

        endDateField = new JTextField();
        addFocusHighlighter(endDateField);
        endDateField.setToolTipText("Format: yyyy-mm-dd (e.g., 2023-12-31)");
        form.add(new JLabel("End Date (yyyy-mm-dd):"));
        form.add(endDateField);

        // Budget with green highlighting
        budgetField = new JTextField();
        addFocusHighlighter(budgetField);
        budgetField.setToolTipText("Positive number with up to 2 decimals (e.g., 15000.50)");
        form.add(new JLabel("Budget:"));
        form.add(budgetField);

        // Status
        statusCombo = new JComboBox<>(new String[]{"Planning", "Ongoing", "Completed", "Cancelled"});
        form.add(new JLabel("Status:"));
        form.add(statusCombo);

        add(form, BorderLayout.SOUTH);
    }

    private void initializeButtons() {
        JPanel buttonPanel = new JPanel();

        JButton addBtn = new JButton("Add Project");
        addBtn.addActionListener(e -> addProject());

        updateBtn = new JButton("Update Project");
        updateBtn.setEnabled(false);
        updateBtn.addActionListener(e -> updateProject());

        deleteBtn = new JButton("Delete Project");
        deleteBtn.setEnabled(false);
        deleteBtn.addActionListener(e -> deleteProject());

        buttonPanel.add(addBtn);
        buttonPanel.add(updateBtn);
        buttonPanel.add(deleteBtn);

        add(buttonPanel, BorderLayout.NORTH);
    }

    private void addFocusHighlighter(JTextField field) {
        field.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent evt) {
                field.setBackground(HIGHLIGHT_COLOR);
            }

            @Override
            public void focusLost(java.awt.event.FocusEvent evt) {
                field.setBackground(Color.WHITE);
            }
        });
    }

    private boolean validateInputs() {
        StringBuilder errors = new StringBuilder();

        // Reset field backgrounds
        startDateField.setBackground(Color.WHITE);
        endDateField.setBackground(Color.WHITE);
        budgetField.setBackground(Color.WHITE);

        // Validate Lead Staff
        if (staffCombo.getSelectedItem() == null) {
            errors.append("- Lead staff must be selected\n");
        }

        // Validate Start Date
        String startDateStr = startDateField.getText().trim();
        if (startDateStr.isEmpty()) {
            errors.append("- Start date is required\n");
            startDateField.setBackground(ERROR_COLOR);
        } else {
            try {
                LocalDate.parse(startDateStr);
            } catch (DateTimeParseException e) {
                errors.append("- Start date must be in yyyy-mm-dd format\n");
                startDateField.setBackground(ERROR_COLOR);
            }
        }

        // Validate End Date
        String endDateStr = endDateField.getText().trim();
        if (!endDateStr.isEmpty()) {
            try {
                LocalDate endDate = LocalDate.parse(endDateStr);
                if (!startDateStr.isEmpty()) {
                    try {
                        LocalDate startDate = LocalDate.parse(startDateStr);
                        if (endDate.isBefore(startDate)) {
                            errors.append("- End date cannot be before start date\n");
                            endDateField.setBackground(ERROR_COLOR);
                        }
                    } catch (DateTimeParseException e) {
                        // Start date error already captured
                    }
                }
            } catch (DateTimeParseException e) {
                errors.append("- End date must be in yyyy-mm-dd format\n");
                endDateField.setBackground(ERROR_COLOR);
            }
        }

        // Validate Budget
        String budgetStr = budgetField.getText().trim();
        if (budgetStr.isEmpty()) {
            errors.append("- Budget is required\n");
            budgetField.setBackground(ERROR_COLOR);
        } else {
            try {
                BigDecimal budget = new BigDecimal(budgetStr);
                if (budget.compareTo(BigDecimal.ZERO) <= 0) {
                    errors.append("- Budget must be positive\n");
                    budgetField.setBackground(ERROR_COLOR);
                }
            } catch (NumberFormatException e) {
                errors.append("- Budget must be a valid number\n");
                budgetField.setBackground(ERROR_COLOR);
            }
        }

        if (!errors.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please fix the following errors:\n\n" + errors,
                    "Input Validation Error",
                    JOptionPane.WARNING_MESSAGE);
            return true;
        }
        return false;
    }

    private void loadStaff() {
        staffCombo.removeAllItems();
        try (Connection con = DBConnector.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(
                    "SELECT s.staffID, r.firstName, r.lastName " +
                            "FROM Staff s JOIN Residents r ON s.residentID = r.residentID"
            );
            while (rs.next()) {
                staffCombo.addItem(new StaffItem(
                        rs.getInt("staffID"),
                        rs.getString("firstName") + " " + rs.getString("lastName")
                ));
            }
        } catch (SQLException e) {
            showError("Error loading staff: " + e.getMessage());
        }
    }

    private void populateFormWithSelectedRow(int row) {
        // Find matching staff
        String staffName = table.getValueAt(row, 1).toString();
        for (int i = 0; i < staffCombo.getItemCount(); i++) {
            if (staffCombo.getItemAt(i).toString().equals(staffName)) {
                staffCombo.setSelectedIndex(i);
                break;
            }
        }

        startDateField.setText(table.getValueAt(row, 2).toString());
        endDateField.setText(table.getValueAt(row, 3).toString());
        budgetField.setText(table.getValueAt(row, 4).toString());
        statusCombo.setSelectedItem(table.getValueAt(row, 5).toString());

        updateBtn.setEnabled(true);
        deleteBtn.setEnabled(true);
    }

    private void addProject() {

        if (validateInputs()) return;

        try (Connection con = DBConnector.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO Project (staffID, startDate, endDate, budget, status) " +
                            "VALUES (?, ?, ?, ?, ?)"
            );

            setStatementParameters(ps);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Project added successfully!");
            clearForm();
            loadProjects();
        } catch (SQLException | IllegalArgumentException ex) {
            showError("Error: " + ex.getMessage());
        }
    }

    private void updateProject() {

        if (validateInputs()) return;

        try (Connection con = DBConnector.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "UPDATE Project SET staffID=?, startDate=?, endDate=?, budget=?, status=? " +
                            "WHERE projectID=?"
            );

            setStatementParameters(ps);
            ps.setInt(6, selectedProjectId);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Project updated successfully!");
            clearForm();
            loadProjects();
        } catch (SQLException | IllegalArgumentException ex) {
            showError("Error: " + ex.getMessage());
        }
    }

    private void deleteProject() {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete this project?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection con = DBConnector.getConnection()) {

                // First delete from ProjectParticipants to maintain referential integrity
                PreparedStatement deleteParticipants = con.prepareStatement(
                        "DELETE FROM ProjectParticipants WHERE projectID=?"
                );
                deleteParticipants.setInt(1, selectedProjectId);
                deleteParticipants.executeUpdate();

                // Then delete the project
                PreparedStatement deleteProject = con.prepareStatement(
                        "DELETE FROM Project WHERE projectID=?"
                );
                deleteProject.setInt(1, selectedProjectId);
                deleteProject.executeUpdate();

                JOptionPane.showMessageDialog(this, "Project deleted successfully!");
                clearForm();
                loadProjects();
            } catch (SQLException ex) {
                showError("Error: " + ex.getMessage());
            }
        }
    }


    private void setStatementParameters(PreparedStatement ps) throws SQLException {
        StaffItem staff = (StaffItem) staffCombo.getSelectedItem();

        if (staff == null) {
            throw new IllegalArgumentException("No staff member selected.");
        }

        String startDateStr = startDateField.getText().trim();
        String endDateStr = endDateField.getText().trim();
        String budgetStr = budgetField.getText().trim();

        LocalDate startDate;
        LocalDate endDate = null;

        try {
            startDate = LocalDate.parse(startDateStr);
        } catch (Exception e) {
            throw new IllegalArgumentException("Start date must be in format yyyy-MM-dd.");
        }

        if (!endDateStr.isEmpty()) {
            try {
                endDate = LocalDate.parse(endDateStr);
            } catch (Exception e) {
                throw new IllegalArgumentException("End date must be in format yyyy-MM-dd or left blank.");
            }

            if (endDate.isBefore(startDate)) {
                throw new IllegalArgumentException("End date cannot be before start date.");
            }
        }

        if (!budgetStr.matches("^\\d+(\\.\\d{1,2})?$")) {
            throw new IllegalArgumentException("Budget must be a number with up to 2 decimal places.");
        }

        ps.setInt(1, staff.id());
        ps.setDate(2, java.sql.Date.valueOf(startDate));
        ps.setDate(3, endDate != null ? java.sql.Date.valueOf(endDate) : null);
        ps.setBigDecimal(4, new java.math.BigDecimal(budgetStr));
        ps.setString(5, (String) statusCombo.getSelectedItem());
    }


    private void clearForm() {
        staffCombo.setSelectedIndex(0);
        startDateField.setText("");
        endDateField.setText("");
        budgetField.setText("");
        statusCombo.setSelectedIndex(0);
        selectedProjectId = -1;
        updateBtn.setEnabled(false);
        deleteBtn.setEnabled(false);
    }

    private void loadProjects() {
        model.setRowCount(0);
        try (Connection con = DBConnector.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(
                    "SELECT p.projectID, CONCAT(r.firstName, ' ', r.lastName) AS staffName, " +
                            "p.startDate, p.endDate, p.budget, p.status " +
                            "FROM Project p " +
                            "JOIN Staff s ON p.staffID = s.staffID " +
                            "JOIN Residents r ON s.residentID = r.residentID"
            );

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("projectID"),
                        rs.getString("staffName"),
                        rs.getDate("startDate").toString(),
                        rs.getDate("endDate") != null ? rs.getDate("endDate").toString() : "",
                        rs.getBigDecimal("budget"),
                        rs.getString("status")
                });
            }
        } catch (SQLException e) {
            showError("Error loading projects: " + e.getMessage());
        }
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Database Error", JOptionPane.ERROR_MESSAGE);
    }

    private record StaffItem(int id, String name) {

        @Override
            public String toString() {
                return name;
            }
        }
}