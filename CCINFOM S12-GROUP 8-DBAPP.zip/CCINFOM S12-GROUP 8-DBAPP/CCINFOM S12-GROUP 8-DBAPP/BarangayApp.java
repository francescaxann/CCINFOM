import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;

public class BarangayApp extends JFrame {

    private final JLabel statusLabel;

    public BarangayApp() throws IOException {

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            UIManager.put("TabbedPane.selected", new Color(70, 130, 180)); // SteelBlue selected tab
            UIManager.put("TabbedPane.tabAreaBackground", new Color(240, 248, 255)); // AliceBlue tab area
        } catch (Exception ignored) {
        }

        setTitle("Barangay Records Management System");
        setSize(1000, 700);  // Slightly larger for better spacing
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Load and set application icon
        try {
            setIconImage(ImageIO.read(new File("resources/baranggay_icon.png")));
        } catch (IOException e) {
            System.out.println("Icon not found, using default");
        }

        // Main content panel with gradient background
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                Color color1 = new Color(240, 248, 255); // AliceBlue
                Color color2 = new Color(230, 240, 255); // Lighter blue
                GradientPaint gp = new GradientPaint(0, 0, color1, getWidth(), getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        JTabbedPane tabs = new JTabbedPane(JTabbedPane.TOP, JTabbedPane.SCROLL_TAB_LAYOUT);
        tabs.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tabs.setForeground(new Color(25, 25, 112)); // MidnightBlue

        addTabWithIcon(tabs, "Residents", "resources/user_icon.png", new ResidentsPanel());
        addTabWithIcon(tabs, "Staff", "resources/staff_icon.png", new StaffPanel());
        addTabWithIcon(tabs, "Incidents", "resources/incident_icon.png", new IncidentPanel());
        addTabWithIcon(tabs, "Projects", "resources/project_icon.png", new ProjectPanel());
        addTabWithIcon(tabs, "Reports", "resources/report_icon.png", new ReportsPanel());
        addTabWithIcon(tabs, "Incident Deployment", "resources/deploy_icon.png", new IncidentDeploymentPanel());
        addTabWithIcon(tabs, "Staff Assignment", "resources/assign_icon.png", new StaffAssignmentPanel());
        addTabWithIcon(tabs, "Certificates", "resources/certificate_icon.png", new ClearancePanel());

        JToolBar toolBar = createModernToolbar();

        statusLabel = new JLabel("Ready");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statusLabel.setForeground(new Color(70, 70, 70));

        JPanel statusPanel = new JPanel(new BorderLayout());
        statusPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(180, 180, 180)),
                BorderFactory.createEmptyBorder(4, 10, 4, 10)
        ));
        statusPanel.setBackground(new Color(245, 245, 245));
        statusPanel.add(statusLabel, BorderLayout.WEST);

        // Add version label to status bar
        JLabel versionLabel = new JLabel("v2.1.0");
        versionLabel.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        versionLabel.setForeground(new Color(100, 100, 100));
        statusPanel.add(versionLabel, BorderLayout.EAST);

        // Add components to main panel
        mainPanel.add(toolBar, BorderLayout.NORTH);
        mainPanel.add(tabs, BorderLayout.CENTER);
        mainPanel.add(statusPanel, BorderLayout.SOUTH);

        // Add header panel with title and logo
        addHeader(mainPanel);

        setContentPane(mainPanel);
    }

    private void addTabWithIcon(JTabbedPane tabs, String title, String iconPath, JComponent panel) {
        ImageIcon icon;
        try {
            icon = new ImageIcon(iconPath);
            Image scaled = icon.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
            icon = new ImageIcon(scaled);
        } catch (Exception e) {
            icon = new ImageIcon(); // Empty icon
        }
        tabs.addTab(title, icon, panel);

        panel.setOpaque(false);
        panel.setBackground(new Color(240, 248, 255, 180)); // Semi-transparent
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
    }

    private JToolBar createModernToolbar() {
        JToolBar toolBar = new JToolBar();
        toolBar.setFloatable(false);
        toolBar.setBackground(new Color(70, 130, 180));
        toolBar.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(25, 25, 112)));

        JLabel titleLabel = new JLabel("BARANGAY RECORDS SYSTEM");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 15, 0, 30));

        toolBar.add(titleLabel);
        toolBar.add(Box.createHorizontalGlue());

        JButton reportAccidentBtn = new JButton("REPORT ACCIDENT");
        styleButton(reportAccidentBtn, new Color(220, 20, 60));

        reportAccidentBtn.addActionListener(e -> {
            new AccidentReportDialog(BarangayApp.this).setVisible(true);
            setStatus("Accident report dialog opened.");
        });

        toolBar.add(reportAccidentBtn);
        toolBar.add(Box.createHorizontalStrut(15));

        return toolBar;
    }

    private void styleButton(JButton button, Color bgColor) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(bgColor.getRed() / 2, bgColor.getGreen() / 2, bgColor.getBlue() / 2), 1),
                BorderFactory.createEmptyBorder(6, 15, 6, 15)
        ));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.brighter());
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });
    }

    private void addHeader(JPanel mainPanel) {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(25, 25, 112));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        // Add logo and title
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        titlePanel.setOpaque(false);

        try {
            ImageIcon logo = new ImageIcon("resources/logo.png");
            Image scaled = logo.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
            JLabel logoLabel = new JLabel(new ImageIcon(scaled));
            titlePanel.add(logoLabel);
        } catch (Exception e) {
            // Use text if logo not found
            JLabel logoPlaceholder = new JLabel("BRMS");
            logoPlaceholder.setFont(new Font("Segoe UI", Font.BOLD, 24));
            logoPlaceholder.setForeground(Color.WHITE);
            titlePanel.add(logoPlaceholder);
        }

        JLabel headerLabel = new JLabel("Barangay Management System");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        headerLabel.setForeground(Color.WHITE);
        headerLabel.setBorder(BorderFactory.createEmptyBorder(0, 15, 0, 0));
        titlePanel.add(headerLabel);

        headerPanel.add(titlePanel, BorderLayout.WEST);

        // Add user info panel
        JPanel userPanel = new JPanel();
        userPanel.setOpaque(false);
        userPanel.add(new JLabel(new ImageIcon("resources/user_icon_small.png")));

        headerPanel.add(userPanel, BorderLayout.EAST);
        mainPanel.add(headerPanel, BorderLayout.NORTH);
    }

    public void setStatus(String message) {
        statusLabel.setText("Status: " + message);
        statusLabel.setForeground(new Color(70, 70, 70));
    }
}