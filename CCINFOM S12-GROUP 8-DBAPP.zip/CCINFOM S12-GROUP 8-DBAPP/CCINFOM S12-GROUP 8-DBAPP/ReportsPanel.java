import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class ReportsPanel extends JPanel {
    private DefaultTableModel model;
    private JComboBox<String> reportSelector;
    private JTextField startDateField, endDateField;

    public ReportsPanel() {
        setLayout(new BorderLayout());
        initializeComponents();
    }

    private void initializeComponents() {
        JPanel topPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(2, 4, 2, 4);
        gbc.anchor = GridBagConstraints.WEST;

        reportSelector = new JComboBox<>(new String[]{
                "Population Census [All Residents]",
                "Population Census [Staff Only]",
                "Average of Accident Reports [Types]",
                "Average of Accident Reports [Status]",
                "HR and Finance Budgeting Statistics",
                "Resident Satisfaction Rating"
        });

        startDateField = new JTextField(10);
        endDateField = new JTextField(10);
        JButton generateBtn = new JButton("Generate Report");
        generateBtn.addActionListener(e -> generateReport());
        JButton exportBtn = new JButton("Export to CSV");
        exportBtn.addActionListener(e -> exportToCSV());

        int row = 0;
        gbc.gridx = 0;
        gbc.gridy = row;
        topPanel.add(new JLabel("Start Date (yyyy-mm-dd): "), gbc);
        gbc.gridx = 1;
        topPanel.add(startDateField, gbc);
        gbc.gridx = 2;
        topPanel.add(new JLabel("End Date (yyyy-mm-dd): "), gbc);
        gbc.gridx = 3;
        topPanel.add(endDateField, gbc);

        gbc.gridx = 0;
        gbc.gridy = ++row;
        topPanel.add(new JLabel("Select Report: "), gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        topPanel.add(reportSelector, gbc);
        gbc.gridx = 3;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        topPanel.add(generateBtn, gbc);
        gbc.gridx = 4;
        topPanel.add(exportBtn, gbc);


        model = new DefaultTableModel();
        JTable reportTable = new JTable(model);

        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(reportTable), BorderLayout.CENTER);
    }

    private void generateReport() {


        String selected = (String) reportSelector.getSelectedItem();
        if (selected == null) return;

        String startText = startDateField.getText().trim();
        String endText = endDateField.getText().trim();

        // Check if dates are empty
        if (startText.isEmpty() || endText.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter both start and end dates.",
                    "Missing Date Input",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Validate format yyyy-MM-dd
        if (!startText.matches("\\d{4}-\\d{2}-\\d{2}") || !endText.matches("\\d{4}-\\d{2}-\\d{2}")) {
            showError("Please enter valid dates in yyyy-MM-dd format.");
            return;
        }

        // Attempt parsing to ensure they're real dates (like not 2025-02-30)
        try {
            LocalDate.parse(startText);
            LocalDate.parse(endText);
        } catch (DateTimeParseException ex) {
            showError("Invalid date values. Please enter valid calendar dates.");
            return;
        }

        model.setRowCount(0);
        model.setColumnCount(0);

        try (Connection con = DBConnector.getConnection()) {
            switch (selected) {
                case "Population Census [All Residents]" -> generatePopulationCensus(con);
                case "Population Census [Staff Only]" -> generateStaffCensusWithAgeGroups(con);
                case "Average of Accident Reports [Types]" -> generateAccidentAverage(con, "eventType");
                case "Average of Accident Reports [Status]" -> generateAccidentAverage(con, "status");
                case "HR and Finance Budgeting Statistics" -> generateHRFinanceStats(con);
                case "Resident Satisfaction Rating" -> generateSatisfactionReport(con);
            }
        } catch (SQLException ex) {
            showError("Error generating report: " + ex.getMessage());
        }
    }

    private void generatePopulationCensus(Connection con) throws SQLException {
        model.setColumnIdentifiers(new String[]{"Age Group", "Male", "Female", "Total"});

        LocalDate start = LocalDate.parse(startDateField.getText());
        LocalDate end = LocalDate.parse(endDateField.getText());

        String sql = "SELECT " +
                "CASE " +
                "WHEN TIMESTAMPDIFF(YEAR, birthDate, CURDATE()) < 25 THEN '0-24' " +
                "WHEN TIMESTAMPDIFF(YEAR, birthDate, CURDATE()) BETWEEN 25 AND 34 THEN '25-34' " +
                "WHEN TIMESTAMPDIFF(YEAR, birthDate, CURDATE()) BETWEEN 35 AND 44 THEN '35-44' " +
                "WHEN TIMESTAMPDIFF(YEAR, birthDate, CURDATE()) BETWEEN 45 AND 54 THEN '45-54' " +
                "WHEN TIMESTAMPDIFF(YEAR, birthDate, CURDATE()) BETWEEN 55 AND 64 THEN '55-64' " +
                "ELSE '65+' END AS age_group, " +
                "gender, COUNT(*) AS count " +
                "FROM Residents " +
                "WHERE residencyStart BETWEEN ? AND ? " +
                "GROUP BY age_group, gender";

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setDate(1, Date.valueOf(start));
        ps.setDate(2, Date.valueOf(end));

        ResultSet rs = ps.executeQuery();

        java.util.Map<String, int[]> census = new java.util.LinkedHashMap<>();
        while (rs.next()) {
            String group = rs.getString("age_group");
            String gender = rs.getString("gender");
            int count = rs.getInt("count");

            census.putIfAbsent(group, new int[2]);
            if ("Male".equals(gender)) census.get(group)[0] = count;
            else census.get(group)[1] = count;
        }

        String[] ageGroupOrder = {"0-24", "25-34", "35-44", "45-54", "55-64", "65+"};
        for (String group : ageGroupOrder) {
            int[] counts = census.getOrDefault(group, new int[]{0, 0});
            int male = counts[0];
            int female = counts[1];
            model.addRow(new Object[]{group, male, female, male + female});
        }
    }

    private void generateStaffCensusWithAgeGroups(Connection con) throws SQLException {
        model.setColumnIdentifiers(new String[]{
                "Age Group",
                "Male [Active]", "Male [Inactive]",
                "Female [Active]", "Female [Inactive]",
                "Total [Active]", "Total [Inactive]", "Total [Overall]"
        });

        LocalDate start = LocalDate.parse(startDateField.getText());
        LocalDate end = LocalDate.parse(endDateField.getText());

        String sql = "SELECT " +
                "CASE " +
                "WHEN TIMESTAMPDIFF(YEAR, r.birthDate, CURDATE()) < 25 THEN '0-24' " +
                "WHEN TIMESTAMPDIFF(YEAR, r.birthDate, CURDATE()) BETWEEN 25 AND 34 THEN '25-34' " +
                "WHEN TIMESTAMPDIFF(YEAR, r.birthDate, CURDATE()) BETWEEN 35 AND 44 THEN '35-44' " +
                "WHEN TIMESTAMPDIFF(YEAR, r.birthDate, CURDATE()) BETWEEN 45 AND 54 THEN '45-54' " +
                "WHEN TIMESTAMPDIFF(YEAR, r.birthDate, CURDATE()) BETWEEN 55 AND 64 THEN '55-64' " +
                "ELSE '60+' END AS age_group, " +
                "r.gender, s.officeStatus, COUNT(*) AS count " +
                "FROM Staff s JOIN Residents r ON s.residentID = r.residentID " +
                "WHERE s.startTerm BETWEEN ? AND ? OR (s.endTerm IS NULL AND s.startTerm <= ?) " +
                "GROUP BY age_group, r.gender, s.officeStatus";

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setDate(1, Date.valueOf(start));
        ps.setDate(2, Date.valueOf(end));
        ps.setDate(3, Date.valueOf(end));

        ResultSet rs = ps.executeQuery();

        class StaffGroup {
            int activeMale = 0, inactiveMale = 0, activeFemale = 0, inactiveFemale = 0;

            int totalActive() {
                return activeMale + activeFemale;
            }

            int totalInactive() {
                return inactiveMale + inactiveFemale;
            }

            int totalOverall() {
                return totalActive() + totalInactive();
            }
        }

        java.util.Map<String, StaffGroup> groupMap = new java.util.LinkedHashMap<>();

        while (rs.next()) {
            String ageGroup = rs.getString("age_group");
            String gender = rs.getString("gender");
            String status = rs.getString("officeStatus");
            int count = rs.getInt("count");

            StaffGroup sg = groupMap.computeIfAbsent(ageGroup, k -> new StaffGroup());

            if ("Male".equals(gender)) {
                if ("Active".equals(status)) sg.activeMale += count;
                else sg.inactiveMale += count;
            } else if ("Female".equals(gender)) {
                if ("Active".equals(status)) sg.activeFemale += count;
                else sg.inactiveFemale += count;
            }
        }

        String[] ageGroupOrder = {"0-24", "25-34", "35-44", "45-54", "55-64", "60+"};
        for (String group : ageGroupOrder) {
            StaffGroup sg = groupMap.getOrDefault(group, new StaffGroup());
            model.addRow(new Object[]{
                    group,
                    sg.activeMale,
                    sg.inactiveMale,
                    sg.activeFemale,
                    sg.inactiveFemale,
                    sg.totalActive(),
                    sg.totalInactive(),
                    sg.totalOverall()
            });
        }
    }

    private void generateAccidentAverage(Connection con, String groupByField) throws SQLException {
        LocalDate start = LocalDate.parse(startDateField.getText());
        LocalDate end = LocalDate.parse(endDateField.getText());
        model.setColumnIdentifiers(new String[]{
                groupByField.equals("eventType") ? "Type of Accident" : capitalize(groupByField),
                "Average Total Incidents",
                "Most Frequent Resident",
                "Most Frequent Staff"
        });

        String sql = "SELECT " + groupByField + ", COUNT(*) / COUNT(DISTINCT CONCAT(YEAR(date), '-', MONTH(date))) AS avgMonthly " +
                "FROM Incident WHERE date BETWEEN ? AND ? GROUP BY " + groupByField;

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setDate(1, Date.valueOf(start));
        ps.setDate(2, Date.valueOf(end));
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            String groupValue = rs.getString(1);
            String avgMonthly = String.format("%.2f", rs.getDouble(2));

            String residentQuery = "SELECT CONCAT(r.firstName, ' ', r.lastName) AS fullName, COUNT(*) AS freq " +
                    "FROM Incident i JOIN Residents r ON i.residentID = r.residentID " +
                    "WHERE " + groupByField + " = ? GROUP BY r.residentID ORDER BY freq DESC LIMIT 1";

            String staffQuery = "SELECT CONCAT(s.firstName, ' ', s.lastName) AS fullName, COUNT(*) AS freq " +
                    "FROM Incident i JOIN Staff st ON i.staffID = st.staffID " +
                    "JOIN Residents s ON st.residentID = s.residentID " +
                    "WHERE " + groupByField + " = ? GROUP BY s.residentID ORDER BY freq DESC LIMIT 1";

            String topResident = "N/A";
            String topStaff = "N/A";

            try (PreparedStatement rps = con.prepareStatement(residentQuery)) {
                rps.setString(1, groupValue);
                ResultSet rrs = rps.executeQuery();
                if (rrs.next()) {
                    topResident = rrs.getString("fullName");
                }
            }

            try (PreparedStatement sps = con.prepareStatement(staffQuery)) {
                sps.setString(1, groupValue);
                ResultSet srs = sps.executeQuery();
                if (srs.next()) {
                    topStaff = srs.getString("fullName");
                }
            }

            model.addRow(new Object[]{groupValue, avgMonthly, topResident, topStaff});
        }
    }

    private void generateHRFinanceStats(Connection con) throws SQLException {
        model.setColumnIdentifiers(new String[]{"Qualified Staff Count", "Project Count", "Total Budget"});

        LocalDate start = LocalDate.parse(startDateField.getText());
        LocalDate end = LocalDate.parse(endDateField.getText());

        PreparedStatement staffStmt = con.prepareStatement(
                "SELECT COUNT(DISTINCT s.staffID) " +
                        "FROM Staff s " +
                        "JOIN ProjectParticipants pp ON s.residentID = pp.residentID " +
                        "WHERE s.officeStatus = 'Active' " +
                        "AND s.startTerm <= ? " +
                        "AND (s.endTerm IS NULL OR s.endTerm >= ?)"
        );
        staffStmt.setDate(1, Date.valueOf(end));
        staffStmt.setDate(2, Date.valueOf(start));

        ResultSet staffCount = staffStmt.executeQuery();
        staffCount.next();
        int totalQualifiedStaff = staffCount.getInt(1);


        PreparedStatement projectStmt = con.prepareStatement(
                "SELECT COUNT(*), COALESCE(SUM(budget), 0) FROM Project " +
                        "WHERE (startDate <= ? AND (endDate IS NULL OR endDate >= ?)) " +
                        "OR (startDate BETWEEN ? AND ?) " +
                        "OR (endDate BETWEEN ? AND ?)"
        );

        projectStmt.setDate(1, Date.valueOf(end));
        projectStmt.setDate(2, Date.valueOf(start));
        projectStmt.setDate(3, Date.valueOf(start));
        projectStmt.setDate(4, Date.valueOf(end));
        projectStmt.setDate(5, Date.valueOf(start));
        projectStmt.setDate(6, Date.valueOf(end));

        ResultSet projectCount = projectStmt.executeQuery();
        projectCount.next();
        int projects = projectCount.getInt(1);
        double budget = projectCount.getDouble(2);

        model.addRow(new Object[]{totalQualifiedStaff, projects, String.format("%.2f", budget)});
    }

    private void generateSatisfactionReport(Connection con) throws SQLException {
        model.setColumnIdentifiers(new String[]{
                "Ave. Satisfaction Rating [Overall]",
                "Ave. Satisfaction Rating [Incident]",
                "Ave. Satisfaction Rating [Projects]"
        });

        LocalDate start = LocalDate.parse(startDateField.getText());
        LocalDate end = LocalDate.parse(endDateField.getText());

        String sqlOverall = "SELECT AVG(satisfactionRating) AS avg FROM Residents";

        String sqlIncident =
                "SELECT AVG(r.satisfactionRating) AS avg " +
                        "FROM Residents r " +
                        "JOIN IncidentParticipants ip ON r.residentID = ip.residentID " +
                        "JOIN Incident i ON ip.reportID = i.reportID " +
                        "WHERE i.date BETWEEN ? AND ?";

        String sqlProject =
                "SELECT AVG(r.satisfactionRating) AS avg " +
                        "FROM Residents r " +
                        "JOIN ProjectParticipants pp ON r.residentID = pp.residentID " +
                        "JOIN Project p ON pp.projectID = p.projectID " +
                        "WHERE (p.startDate <= ? AND (p.endDate IS NULL OR p.endDate >= ?)) " +
                        "OR (p.startDate BETWEEN ? AND ?) " +
                        "OR (p.endDate BETWEEN ? AND ?)";

        double overall = queryAverage(con, sqlOverall);

        double incident = 0.0;
        try (PreparedStatement ps = con.prepareStatement(sqlIncident)) {
            ps.setDate(1, Date.valueOf(start));
            ps.setDate(2, Date.valueOf(end));
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) incident = rs.getDouble(1);
            }
        }

        double project = 0.0;
        try (PreparedStatement ps = con.prepareStatement(sqlProject)) {
            ps.setDate(1, Date.valueOf(end));
            ps.setDate(2, Date.valueOf(start));
            ps.setDate(3, Date.valueOf(start));
            ps.setDate(4, Date.valueOf(end));
            ps.setDate(5, Date.valueOf(start));
            ps.setDate(6, Date.valueOf(end));
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) project = rs.getDouble(1);
            }
        }

        model.addRow(new Object[]{
                String.format("%.2f", overall),
                String.format("%.2f", incident),
                String.format("%.2f", project)
        });
    }


    private double queryAverage(Connection con, String sql) throws SQLException {
        try (Statement stmt = con.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            return rs.next() ? rs.getDouble(1) : 0.0;
        }
    }

    private String capitalize(String text) {
        if (text == null || text.isEmpty()) return text;
        return text.substring(0, 1).toUpperCase() + text.substring(1);
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Database Error", JOptionPane.ERROR_MESSAGE);
    }

    private void exportToCSV() {
        if (model.getRowCount() == 0) {
            showError("No data to export.");
            return;
        }

        String selected = (String) reportSelector.getSelectedItem();
        assert selected != null;
        String filenamePrefix = switch (selected) {
            case "Population Census [All Residents]" -> "PopulationCensusAllResidents";
            case "Population Census [Staff Only]" -> "PopulationCensusStaffOnly";
            case "Average of Accident Reports [Types]" -> "AverageOfAccidentReportsTypes";
            case "Average of Accident Reports [Status]" -> "AverageOfAccidentReportsStatus";
            case "HR and Finance Budgeting Statistics" -> "HRFinanceBudgetingStatistics";
            case "Resident Satisfaction Rating" -> "ResidentSatisfactionRating";
            default -> "Report";
        };

        String dateNow = LocalDate.now().toString();
        String fileName = filenamePrefix + "[" + dateNow + "].csv";

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setSelectedFile(new java.io.File(fileName));
        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection != JFileChooser.APPROVE_OPTION) return;

        java.io.File fileToSave = fileChooser.getSelectedFile();

        try (java.io.FileWriter fw = new java.io.FileWriter(fileToSave);
             java.io.BufferedWriter bw = new java.io.BufferedWriter(fw)) {

            String barangayName = "Barangay Report - " + selected;

            // Header
            bw.write(barangayName);
            bw.newLine();
            bw.newLine();
            bw.write("Start Date: " + startDateField.getText());
            bw.newLine();
            bw.write("End Date: " + endDateField.getText());
            bw.newLine();
            bw.newLine();

            // Column headers
            for (int i = 0; i < model.getColumnCount(); i++) {
                bw.write(model.getColumnName(i));
                if (i != model.getColumnCount() - 1) bw.write(",");
            }
            bw.newLine();

            // Rows
            for (int row = 0; row < model.getRowCount(); row++) {
                for (int col = 0; col < model.getColumnCount(); col++) {
                    Object value = model.getValueAt(row, col);
                    bw.write(value == null ? "" : value.toString());
                    if (col != model.getColumnCount() - 1) bw.write(",");
                }
                bw.newLine();
            }

            bw.flush();
            JOptionPane.showMessageDialog(this, "CSV exported to:\n" + fileToSave.getAbsolutePath(),
                    "Export Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            showError("Failed to export CSV: " + ex.getMessage());
        }
    }
}


