import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class SplashScreen extends JWindow {
    private final JLabel label = new JLabel("", JLabel.CENTER);
    private final String[] asciiArtLines = {
            "Loading Barangay System...\n",
            " ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
            " ⠀⠀⠀⠀⠀⢠⣤⣤⣤⡄⠀⠀⢀⣴⠟⠻⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
            " ⠀⠀⠀⠀⠀⢸⣿⣿⣿⠇⢀⣴⠟⣡⣾⣷⣌⠻⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀",
            " ⠀⠀⠀⠀⠀⢸⣿⠟⢁⣴⠟⣡⣾⣿⣿⣿⣿⣷⣌⠻⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀",
            " ⠀⠀⠀⠀⠀⠘⢁⣴⠟⢁⣴⣿⣿⣿⣿⣿⣿⣿⣿⣦⡈⠻⣦⡀⠀⠀⠀⠀⠀⠀",
            " ⠀⠀⠀⠀⢀⣴⠟⣡⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣦⣌⠻⣦⡀⠀⠀⠀⠀",
            " ⠀⠀⢀⣴⠟⣡⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣌⠻⣦⡀⠀⠀",
            " ⠀⠰⠟⠁⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⠈⠻⠆⠀",
            " ⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀",
            " ⠀⠀⠀⠀⣿⣿⣿⡏⠉⠉⠉⠉⠉⣿⣿⣿⣿⠉⠉⠉⠉⠉⢹⣿⣿⣿⠀⠀⠀⠀",
            " ⠀⠀⠀⠀⣿⣿⣿⡇⠀⠀⠀⠀⠀ ⣿⣿⣿⣿⠀⠀⠀⠀⠀  ⣿⣿⣿⡇",
            " ⠀⠀⠀⠀⣿⣿⣿⡇⠀⠀⠀⠀⠀ ⣿⣿⣿⣿⣀⣀⣀⣀⣀⣸⣿⣿⣿⠀⠀⠀⠀",
            " ⠀⠀⠀⠀⣿⣿⣿⡇⠀⠀⠀⠀⠀ ⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀",
            " ⠀⠀⠀⠀⣿⣿⣿⡇⠀⠀⠀⠀⠀ ⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀",
            " ⠀⠀⠀⠀⠉⠉⠉⠁⠀⠀⠀⠀⠀ ⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠀⠀⠀⠀"
    };

    public SplashScreen() {
        GradientPanel content = new GradientPanel();
        content.setLayout(new BorderLayout());

        label.setFont(new Font("Monospaced", Font.BOLD, 16));
        label.setForeground(Color.WHITE);
        label.setBorder(BorderFactory.createEmptyBorder(40, 20, 40, 20));
        label.setVerticalAlignment(SwingConstants.CENTER);

        content.add(label, BorderLayout.CENTER);

        setContentPane(content);
        setSize(700, 500);
        setLocationRelativeTo(null);
    }

    public void showSplash() {
        setVisible(true);

        StringBuilder builder = new StringBuilder();
        Timer timer = new Timer(120, null);
        final int[] index = {0};

        timer.addActionListener(e -> {
            if (index[0] < asciiArtLines.length) {
                builder.append(asciiArtLines[index[0]++]).append("<br>");
                label.setText("<html><pre>" + builder + "</pre></html>");
            } else {
                timer.stop();
                try {
                    Thread.sleep(600);
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                }
                setVisible(false);
                dispose();

                SwingUtilities.invokeLater(() -> {
                    try {
                        new BarangayApp().setVisible(true);
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                });
            }
        });

        timer.start();
    }

    static class GradientPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;

            Color color1 = new Color(0x1565C0); // blue
            Color color2 = new Color(0x81D4FA); // light blue

            int width = getWidth();
            int height = getHeight();
            GradientPaint gp = new GradientPaint(0, 0, color1, width, height, color2);
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, width, height);
        }
    }
}
