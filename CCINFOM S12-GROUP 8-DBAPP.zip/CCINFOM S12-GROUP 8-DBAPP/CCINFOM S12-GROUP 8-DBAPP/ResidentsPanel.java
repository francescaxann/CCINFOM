import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.sql.*;
import java.time.LocalDate;

public class ResidentsPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private JTextField[] fields;
    private JComboBox<String> genderCombo, civilStatusCombo;

    public ResidentsPanel() {
        setLayout(new BorderLayout());
        initializeUI();
        loadResidents();
    }

    private void initializeUI() {

        // Table setup
        model = new DefaultTableModel(new String[] {
                "ID", "First Name", "Last Name", "Birth Date", "Gender", "Civil Status",
                "Occupation", "Contact", "Street", "Residency Start", "Rating"
        }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setRowSelectionAllowed(true);
        table.setFocusable(true);
        table.setRowHeight(24);
        table.setSelectionBackground(new Color(220, 220, 255));
        table.setSelectionForeground(Color.BLACK);

        // Form setup
        JPanel form = new JPanel(new GridLayout(0, 2, 5, 5));
        String[] labels = {"First Name", "Last Name", "Birth Date (yyyy-mm-dd)", "Gender", "Civil Status",
                "Occupation", "Contact No", "Street", "Residency Start (yyyy-mm-dd)", "Rating"};

        fields = new JTextField[labels.length];
        for (int i = 0; i < fields.length; i++) {
            if (i == 3) {
                genderCombo = new JComboBox<>(new String[]{"Male", "Female"});
                form.add(new JLabel(labels[i]));
                form.add(genderCombo);
            } else if (i == 4) {
                civilStatusCombo = new JComboBox<>(new String[]{"Single", "Married", "Divorced", "Widowed"});
                form.add(new JLabel(labels[i]));
                form.add(civilStatusCombo);
            } else {
                form.add(new JLabel(labels[i]));
                fields[i] = new JTextField();
                form.add(fields[i]);
            }
        }

        // Button panel
        JPanel buttonPanel = createButtonPanel();

        // Selection listener
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                populateFormFromSelectedRow();
            }
        });

        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel southPanel = new JPanel(new BorderLayout());
        southPanel.add(form, BorderLayout.NORTH);
        southPanel.add(buttonPanel, BorderLayout.SOUTH);
        add(southPanel, BorderLayout.SOUTH);

        addFieldFocusListeners();
    }

    private JPanel createButtonPanel() {

        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton clearBtn = new JButton("Clear");

        addBtn.addActionListener(e -> addResident());
        updateBtn.addActionListener(e -> updateResident());
        deleteBtn.addActionListener(e -> deleteResident());
        clearBtn.addActionListener(e -> clearForm());

        panel.add(addBtn);
        panel.add(updateBtn);
        panel.add(deleteBtn);
        panel.add(clearBtn);

        return panel;
    }

    private void addFieldFocusListeners() {
        for (JTextField field : fields) {
            if (field != null) {
                addFocusHighlighter(field);
            }
        }
    }

    private void addFocusHighlighter(JTextField field) {
        field.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent evt) {
                field.setBackground(new Color(220, 255, 220));
            }

            public void focusLost(FocusEvent evt) {
                field.setBackground(Color.WHITE);
            }
        });
    }

    private boolean isValidInput() {
        StringBuilder errors = new StringBuilder();
        boolean isValid = true;

        // Reset all field backgrounds
        for (JTextField field : fields) {
            if (field != null) field.setBackground(Color.WHITE);
        }

        // First Name
        if (!fields[0].getText().trim().matches("[a-zA-Z\\s]+")) {
            errors.append("- First name must only contain letters and spaces\n");
            fields[0].setBackground(new Color(255, 200, 200));
            isValid = false;
        }

        // Last Name
        if (!fields[1].getText().trim().matches("[a-zA-Z\\s]+")) {
            errors.append("- Last name must only contain letters and spaces\n");
            fields[1].setBackground(new Color(255, 200, 200));
            isValid = false;
        }

        // Birth Date
        try {
            LocalDate.parse(fields[2].getText().trim());
        } catch (Exception e) {
            errors.append("- Birth date must be in yyyy-mm-dd format\n");
            fields[2].setBackground(new Color(255, 200, 200));
            isValid = false;
        }

        // Occupation
        if (fields[5].getText().trim().isEmpty()) {
            errors.append("- Occupation is required\n");
            fields[5].setBackground(new Color(255, 200, 200));
            isValid = false;
        }

        // Contact No
        if (!fields[6].getText().trim().matches("\\d+")) {
            errors.append("- Contact number must be numeric\n");
            fields[6].setBackground(new Color(255, 200, 200));
            isValid = false;
        }

        // Street
        if (fields[7].getText().trim().isEmpty()) {
            errors.append("- Street is required\n");
            fields[7].setBackground(new Color(255, 200, 200));
            isValid = false;
        }

        // Residency Start
        try {
            LocalDate.parse(fields[8].getText().trim());
        } catch (Exception e) {
            errors.append("- Residency start date must be in yyyy-mm-dd format\n");
            fields[8].setBackground(new Color(255, 200, 200));
            isValid = false;
        }

        // Rating
        try {
            double rating = Double.parseDouble(fields[9].getText().trim());
            if (rating < 0 || rating > 10) {
                throw new NumberFormatException();
            }
        } catch (Exception e) {
            errors.append("- Rating must be a number between 0 and 10\n");
            fields[9].setBackground(new Color(255, 200, 200));
            isValid = false;
        }

        if (!isValid) {
            JOptionPane.showMessageDialog(this,
                    "Please correct the following errors:\n\n" + errors,
                    "Input Validation Error",
                    JOptionPane.WARNING_MESSAGE);
        }

        return !isValid;
    }


    private void loadResidents() {
        model.setRowCount(0);
        try (Connection con = DBConnector.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Residents");
            while (rs.next()) {
                model.addRow(new Object[] {
                        rs.getInt("residentID"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getDate("birthDate").toString(),
                        rs.getString("gender"),
                        rs.getString("civilStatus"),
                        rs.getString("occupation"),
                        rs.getString("contactNo"),
                        rs.getString("streetName"),
                        rs.getDate("residencyStart").toString(),
                        rs.getDouble("satisfactionRating")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading residents: " + e.getMessage());
        }
    }

    private void addResident() {

        if (isValidInput()) return;

        try {
            String sql = "INSERT INTO Residents (firstName, lastName, birthDate, gender, civilStatus, " +
                    "occupation, contactNo, streetName, residencyStart, satisfactionRating) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            try (Connection con = DBConnector.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, fields[0].getText());
                ps.setString(2, fields[1].getText());
                ps.setString(3, fields[2].getText());
                ps.setString(4, (String) genderCombo.getSelectedItem());
                ps.setString(5, (String) civilStatusCombo.getSelectedItem());
                ps.setString(6, fields[5].getText());
                ps.setString(7, fields[6].getText());
                ps.setString(8, fields[7].getText());
                ps.setString(9, fields[8].getText());
                ps.setDouble(10, Double.parseDouble(fields[9].getText()));

                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Resident added successfully!");
                loadResidents();
                clearForm();
            }
        } catch (Exception ignored) {

        }
    }

    private void updateResident() {

        if (isValidInput()) return;

        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a resident to update");
            return;
        }

        int residentId = (int) model.getValueAt(selectedRow, 0);

        try {
            String sql = "UPDATE Residents SET firstName=?, lastName=?, birthDate=?, gender=?, " +
                    "civilStatus=?, occupation=?, contactNo=?, streetName=?, " +
                    "residencyStart=?, satisfactionRating=? WHERE residentID=?";

            try (Connection con = DBConnector.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, fields[0].getText());
                ps.setString(2, fields[1].getText());
                ps.setString(3, fields[2].getText());
                ps.setString(4, (String) genderCombo.getSelectedItem());
                ps.setString(5, (String) civilStatusCombo.getSelectedItem());
                ps.setString(6, fields[5].getText());
                ps.setString(7, fields[6].getText());
                ps.setString(8, fields[7].getText());
                ps.setString(9, fields[8].getText());
                ps.setDouble(10, Double.parseDouble(fields[9].getText()));
                ps.setInt(11, residentId);

                int updated = ps.executeUpdate();
                if (updated > 0) {
                    JOptionPane.showMessageDialog(this, "Resident updated successfully!");
                    loadResidents();
                    clearForm();
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error updating resident: " + e.getMessage());
        }
    }

    private void deleteResident() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a resident to delete");
            return;
        }

        int residentId = (int) model.getValueAt(selectedRow, 0);
        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete resident ID " + residentId + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection con = DBConnector.getConnection();
                 PreparedStatement ps = con.prepareStatement("DELETE FROM Residents WHERE residentID=?")) {

                ps.setInt(1, residentId);
                int deleted = ps.executeUpdate();
                if (deleted > 0) {
                    JOptionPane.showMessageDialog(this, "Resident deleted successfully!");
                    loadResidents();
                    clearForm();
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error deleting resident: " + e.getMessage());
            }
        }
    }

    private void populateFormFromSelectedRow() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {

            fields[0].setText(model.getValueAt(selectedRow, 1).toString());
            fields[1].setText(model.getValueAt(selectedRow, 2).toString());
            fields[2].setText(model.getValueAt(selectedRow, 3).toString());
            genderCombo.setSelectedItem(model.getValueAt(selectedRow, 4).toString());
            civilStatusCombo.setSelectedItem(model.getValueAt(selectedRow, 5).toString());
            fields[5].setText(model.getValueAt(selectedRow, 6).toString());
            fields[6].setText(model.getValueAt(selectedRow, 7).toString());
            fields[7].setText(model.getValueAt(selectedRow, 8).toString());
            fields[8].setText(model.getValueAt(selectedRow, 9).toString());
            fields[9].setText(model.getValueAt(selectedRow, 10).toString());
        }
    }

    private void clearForm() {
        for (JTextField field : fields) {
            if (field != null) field.setText("");
        }
        if (genderCombo != null) genderCombo.setSelectedIndex(0);
        if (civilStatusCombo != null) civilStatusCombo.setSelectedIndex(0);
        table.clearSelection();
    }
}
