import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;

public class IncidentPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private JComboBox<ResidentItem> residentCombo;
    private JComboBox<StaffItem> staffCombo;
    private JTextField eventTypeField, dateField, timeField, locationField, personField;
    private JComboBox<String> statusCombo;
    private JButton updateBtn, deleteBtn;
    private int selectedReportId = -1;

    public IncidentPanel() {
        setLayout(new BorderLayout());
        initializeTable();
        initializeForm();
        initializeButtons();
    }

    private void initializeTable() {
        model = new DefaultTableModel(new String[]{
                "Report ID", "Resident", "Staff", "Event Type", "Date", "Time", "Location", "Person Involved", "Status"
        }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                int row = table.getSelectedRow();
                selectedReportId = (int) table.getValueAt(row, 0);
                populateFormWithSelectedRow(row);
            }
        });

        add(new JScrollPane(table), BorderLayout.CENTER);
        loadIncidents();
    }

    private void initializeForm() {
        JPanel form = new JPanel(new GridLayout(0, 2, 5, 5));

        // Resident combo
        residentCombo = new JComboBox<>();
        loadResidents();
        form.add(new JLabel("Resident:"));
        form.add(residentCombo);

        // Staff combo
        staffCombo = new JComboBox<>();
        loadStaff();
        form.add(new JLabel("Staff:"));
        form.add(staffCombo);

        // Event Type
        eventTypeField = new JTextField();
        form.add(new JLabel("Event Type:"));
        form.add(eventTypeField);

        // Date
        dateField = new JTextField();
        form.add(new JLabel("Date (yyyy-mm-dd):"));
        form.add(dateField);

        // Time
        timeField = new JTextField();
        form.add(new JLabel("Time (HH:mm:ss):"));
        form.add(timeField);

        // Location
        locationField = new JTextField();
        form.add(new JLabel("Location:"));
        form.add(locationField);

        // Person Involved
        personField = new JTextField();
        form.add(new JLabel("Person/s Involved:"));
        form.add(personField);

        // Status
        statusCombo = new JComboBox<>(new String[]{"Pending", "Assigned", "Under Investigation", "Resolved"});
        form.add(new JLabel("Status:"));
        form.add(statusCombo);

        add(form, BorderLayout.SOUTH);

        dateField.setToolTipText("Format: yyyy-mm-dd (e.g., 2023-12-31)");
        timeField.setToolTipText("Format: HH:mm:ss (e.g., 14:30:00)");

        addFieldFocusListeners();
    }

    private void initializeButtons() {
        JPanel buttonPanel = new JPanel();

        JButton addBtn = new JButton("Add Incident");
        addBtn.addActionListener(e -> addIncident());

        updateBtn = new JButton("Update Incident");
        updateBtn.setEnabled(false);
        updateBtn.addActionListener(e -> updateIncident());

        deleteBtn = new JButton("Delete Incident");
        deleteBtn.setEnabled(false);
        deleteBtn.addActionListener(e -> deleteIncident());

        buttonPanel.add(addBtn);
        buttonPanel.add(updateBtn);
        buttonPanel.add(deleteBtn);

        add(buttonPanel, BorderLayout.NORTH);
    }

    private void loadResidents() {
        residentCombo.removeAllItems();
        try (Connection con = DBConnector.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT residentID, firstName, lastName FROM Residents");
            while (rs.next()) {
                residentCombo.addItem(new ResidentItem(
                        rs.getInt("residentID"),
                        rs.getString("firstName") + " " + rs.getString("lastName")
                ));
            }
        } catch (SQLException e) {
            showError("Error loading residents: " + e.getMessage());
        }
    }

    private void loadStaff() {
        staffCombo.removeAllItems();
        try (Connection con = DBConnector.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(
                    "SELECT s.staffID, r.firstName, r.lastName " +
                            "FROM Staff s JOIN Residents r ON s.residentID = r.residentID"
            );
            while (rs.next()) {
                staffCombo.addItem(new StaffItem(
                        rs.getInt("staffID"),
                        rs.getString("firstName") + " " + rs.getString("lastName")
                ));
            }
        } catch (SQLException e) {
            showError("Error loading staff: " + e.getMessage());
        }
    }

    private void populateFormWithSelectedRow(int row) {

        // Find matching resident
        String residentName = table.getValueAt(row, 1).toString();
        for (int i = 0; i < residentCombo.getItemCount(); i++) {
            if (residentCombo.getItemAt(i).toString().equals(residentName)) {
                residentCombo.setSelectedIndex(i);
                break;
            }
        }

        // Find matching staff
        String staffName = table.getValueAt(row, 2).toString();
        for (int i = 0; i < staffCombo.getItemCount(); i++) {
            if (staffCombo.getItemAt(i).toString().equals(staffName)) {
                staffCombo.setSelectedIndex(i);
                break;
            }
        }

        eventTypeField.setText(table.getValueAt(row, 3).toString());
        dateField.setText(table.getValueAt(row, 4).toString());
        timeField.setText(table.getValueAt(row, 5).toString());
        locationField.setText(table.getValueAt(row, 6).toString());
        personField.setText(table.getValueAt(row, 7).toString());
        statusCombo.setSelectedItem(table.getValueAt(row, 8).toString());

        updateBtn.setEnabled(true);
        deleteBtn.setEnabled(true);
    }

    private boolean validateInputs() {

        StringBuilder errors = new StringBuilder();
        Color errorColor = new Color(255, 200, 200);

        // Reset all field backgrounds
        eventTypeField.setBackground(Color.WHITE);
        dateField.setBackground(Color.WHITE);
        timeField.setBackground(Color.WHITE);
        locationField.setBackground(Color.WHITE);
        personField.setBackground(Color.WHITE);

        // Validate Event Type
        if (eventTypeField.getText().trim().isEmpty()) {
            errors.append("- Event Type is required\n");
            eventTypeField.setBackground(errorColor);
        }

        // Validate Date
        if (dateField.getText().trim().isEmpty()) {
            errors.append("- Date is required\n");
            dateField.setBackground(errorColor);
        } else {
            try {
                LocalDate.parse(dateField.getText().trim());
            } catch (DateTimeParseException e) {
                errors.append("- Date must be in yyyy-mm-dd format\n");
                dateField.setBackground(errorColor);
            }
        }

        // Validate Time
        if (timeField.getText().trim().isEmpty()) {
            errors.append("- Time is required\n");
            timeField.setBackground(errorColor);
        } else {
            try {
                LocalTime.parse(timeField.getText().trim());
            } catch (DateTimeParseException e) {
                errors.append("- Time must be in HH:mm:ss format (24-hour)\n");
                timeField.setBackground(errorColor);
            }
        }

        // Validate Location
        if (locationField.getText().trim().isEmpty()) {
            errors.append("- Location is required\n");
            locationField.setBackground(errorColor);
        }

        // Validate Persons Involved
        if (personField.getText().trim().isEmpty()) {
            errors.append("- Persons Involved is required\n");
            personField.setBackground(errorColor);
        }

        if (!errors.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please fix the following errors:\n\n" + errors,
                    "Input Validation Error",
                    JOptionPane.WARNING_MESSAGE);
            return true;
        }
        return false;
    }

    private void addFieldFocusListeners() {
        addFocusHighlighter(eventTypeField);
        addFocusHighlighter(dateField);
        addFocusHighlighter(timeField);
        addFocusHighlighter(locationField);
        addFocusHighlighter(personField);
    }

    private void addFocusHighlighter(JTextField field) {
        field.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                field.setBackground(new Color(220, 255, 220));
            }

            public void focusLost(java.awt.event.FocusEvent evt) {
                field.setBackground(Color.WHITE);
            }
        });
    }

    private void addIncident() {

        if (validateInputs()) return;

        try (Connection con = DBConnector.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO Incident (residentID, staffID, eventType, date, time, " +
                            "location, personInvolved, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
            );

            setStatementParameters(ps);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Incident added successfully!");
            clearForm();
            loadIncidents();
        } catch (SQLException | IllegalArgumentException ex) {
            showError("Error: " + ex.getMessage());
        }
    }

    private void updateIncident() {

        if (validateInputs()) return;

        try (Connection con = DBConnector.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "UPDATE Incident SET residentID=?, staffID=?, eventType=?, date=?, " +
                            "time=?, location=?, personInvolved=?, status=? WHERE reportID=?"
            );

            setStatementParameters(ps);
            ps.setInt(9, selectedReportId);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Incident updated successfully!");
            clearForm();
            loadIncidents();
        } catch (SQLException | IllegalArgumentException ex) {
            showError("Error: " + ex.getMessage());
        }
    }

    private void deleteIncident() {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete this incident?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection con = DBConnector.getConnection()) {
                PreparedStatement ps = con.prepareStatement(
                        "DELETE FROM Incident WHERE reportID=?"
                );
                ps.setInt(1, selectedReportId);
                ps.executeUpdate();

                JOptionPane.showMessageDialog(this, "Incident deleted successfully!");
                clearForm();
                loadIncidents();
            } catch (SQLException ex) {
                showError("Error: " + ex.getMessage());
            }
        }
    }

    private void setStatementParameters(PreparedStatement ps) throws SQLException {
        ResidentItem resident = (ResidentItem) residentCombo.getSelectedItem();
        StaffItem staff = (StaffItem) staffCombo.getSelectedItem();

        if (resident == null || staff == null) {
            throw new IllegalArgumentException("Resident or Staff not selected.");
        }

        ps.setInt(1, resident.id());
        ps.setInt(2, staff.id());
        ps.setString(3, eventTypeField.getText());
        ps.setDate(4, java.sql.Date.valueOf(LocalDate.parse(dateField.getText())));
        ps.setTime(5, java.sql.Time.valueOf(LocalTime.parse(timeField.getText())));
        ps.setString(6, locationField.getText());
        ps.setString(7, personField.getText());
        ps.setString(8, (String) statusCombo.getSelectedItem());
    }

    private void clearForm() {
        residentCombo.setSelectedIndex(0);
        staffCombo.setSelectedIndex(0);
        eventTypeField.setText("");
        dateField.setText("");
        timeField.setText("");
        locationField.setText("");
        personField.setText("");
        statusCombo.setSelectedIndex(0);
        selectedReportId = -1;
        updateBtn.setEnabled(false);
        deleteBtn.setEnabled(false);
    }

    private void loadIncidents() {
        model.setRowCount(0);
        try (Connection con = DBConnector.getConnection()) {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(
                    "SELECT i.reportID, " +
                            "CONCAT(r1.firstName, ' ', r1.lastName) AS residentName, " +
                            "CONCAT(r2.firstName, ' ', r2.lastName) AS staffName, " +
                            "i.eventType, i.date, i.time, i.location, i.personInvolved, i.status " +
                            "FROM Incident i " +
                            "JOIN Residents r1 ON i.residentID = r1.residentID " +
                            "JOIN Staff s ON i.staffID = s.staffID " +
                            "JOIN Residents r2 ON s.residentID = r2.residentID"
            );

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("reportID"),
                        rs.getString("residentName"),
                        rs.getString("staffName"),
                        rs.getString("eventType"),
                        rs.getDate("date").toString(),
                        rs.getTime("time").toString(),
                        rs.getString("location"),
                        rs.getString("personInvolved"),
                        rs.getString("status")
                });
            }
        } catch (SQLException e) {
            showError("Error loading incidents: " + e.getMessage());
        }
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Database Error", JOptionPane.ERROR_MESSAGE);
    }

    private record ResidentItem(int id, String name) {

        @Override
            public String toString() {
                return name;
            }
        }

    private record StaffItem(int id, String name) {

        @Override
            public String toString() {
                return name;
            }
        }
}
